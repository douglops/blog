# Sacred-texts.com topic index: non-human intelligences, sky/star beings, otherworld visitors

Generated 2026-09-26 | Source: https://sacred-texts.com/ (parsed via archive.sacred-texts.com classic index pages)

**Scope:** indexing phase for a comparative religion/folklore study. 77 top-level categories reviewed; 253 candidate texts (high 57, medium 116, low 80) plus 8 African books rated 'none' for completeness.

**Legend:** relevance = high / medium / low. Type: P primary text, E ethnography/folklore collection, S secondary scholarship, **F fringe/esoteric/pseudo-historical**, **U modern UFO/contactee/NRM document**, L literary fiction. Motif codes are listed below.

## Contents

1. Motif themes
2. Top high-relevance texts
3. Index by category
4. Traditions with no clear relevant material / gaps
5. Methodological caveats

## 1. Cross-cutting motif themes

### SKY: Sky descent: gods/beings descend from sky or stars to earth

[Myths and Legends of the Bantu](https://sacred-texts.com/afr/mlb/index.htm) (H); [Myths of Ife](https://sacred-texts.com/afr/ife/index.htm) (H); [Sumerian Mythology](https://sacred-texts.com/ane/sum/index.htm) (H); [The Seven Tablets of Creation (Enuma Elish)](https://sacred-texts.com/ane/stc/index.htm) (H); [Myths and Legends of Babylonia and Assyria](https://sacred-texts.com/ane/mba/index.htm) (H); [The Book of Enoch](https://sacred-texts.com/bib/boe/index.htm) (H); [The Book of Enoch the Prophet](https://sacred-texts.com/bib/bep/index.htm) (H); [The Forgotten Books of Eden (incl. 2 Enoch)](https://sacred-texts.com/bib/fbe/index.htm) (H); [King James Bible: Genesis 6](https://sacred-texts.com/bib/kjv/gen006.htm) (H); [King James Bible: Ezekiel 1](https://sacred-texts.com/bib/kjv/eze001.htm) (H); [Legends of the Jews](https://sacred-texts.com/jud/loj/index.htm) (H); [The Kojiki](https://sacred-texts.com/shi/kj/index.htm) (H); [Nihongi (Part 1 of 4)](https://sacred-texts.com/shi/nihon0.htm) (H); [Iroquoian Cosmology](https://sacred-texts.com/nam/iro/irc/index.htm) (H); [The Myths of Mexico and Peru](https://sacred-texts.com/nam/mmp/index.htm) (H); [Viracocha and the Coming of the Incas](https://sacred-texts.com/nam/inca/inca01.htm) (H); [Chinigchinich (Boscana)](https://sacred-texts.com/nam/ca/bosc/index.htm) (H); [The Lore of the Whare-Wananga](https://sacred-texts.com/pac/lww/index.htm) (H); [The Euahlayi Tribe](https://sacred-texts.com/aus/tet/index.htm) (H); [The Second Battle of Mag Tuired (Cath Maige Tuired)](https://sacred-texts.com/neu/cmt/cmteng.htm) (H); [The Poetic Edda](https://sacred-texts.com/neu/poe/index.htm) (H); [The Secret Doctrine](https://sacred-texts.com/the/sd/index.htm) (H); [The Book of Dzyan (excerpt)](https://sacred-texts.com/atl/dzyan/dzyan.htm) (H); [A Textbook of Theosophy](https://sacred-texts.com/the/tot/index.htm) (H); [Initiation, Human and Solar](https://sacred-texts.com/eso/ihas/index.htm) (H); [The Lost Lemuria](https://sacred-texts.com/atl/tll/index.htm) (H); [Unveiled Mysteries](https://sacred-texts.com/eso/um/index.htm) (H); [Oahspe, A Kosmon Bible](https://sacred-texts.com/oah/oah/index.htm) (H); [Other Tongues--Other Flesh](https://sacred-texts.com/ufo/otof/index.htm) (H); [Heaven's Gate](https://sacred-texts.com/ufo/hg/index.htm) (H); [The Religious System of the Amazulu](https://sacred-texts.com/afr/rsa/index.htm) (M); [Specimens of Bushman Folklore](https://sacred-texts.com/afr/sbf/index.htm) (M); [Notes on the Folklore of the Fjort](https://sacred-texts.com/afr/fjort/index.htm) (M); [The Yoruba Speaking Peoples](https://sacred-texts.com/afr/yor/index.htm) (M); [Yoruba Legends](https://sacred-texts.com/afr/yl/index.htm) (M); [The Enuma Elish (single-page text)](https://sacred-texts.com/ane/enuma.htm) (M); [The Chaldean Account of Genesis](https://sacred-texts.com/ane/caog/index.htm) (M); [The Babylonian Legends of Creation](https://sacred-texts.com/ane/blc/index.htm) (M); [Records of the Past](https://sacred-texts.com/ane/rp/index.htm) (M); [Legends of the Gods: The Egyptian Texts](https://sacred-texts.com/egy/leg/index.htm) (M); [Pistis Sophia](https://sacred-texts.com/chr/ps/index.htm) (M); [Fragments of a Faith Forgotten](https://sacred-texts.com/gno/fff/index.htm) (M); [Thrice-Greatest Hermes (3 vols)](https://sacred-texts.com/gno/th1/index.htm) (M); [The Virgin of the World (Kore Kosmou)](https://sacred-texts.com/eso/vow/index.htm) (M); [The Zend Avesta II: Sirozahs, Yasts (SBE 23)](https://sacred-texts.com/zor/sbe23/index.htm) (M); [Pahlavi Texts I: Bundahishn etc. (SBE 5)](https://sacred-texts.com/zor/sbe05/index.htm) (M); [The Rig-Veda](https://sacred-texts.com/hin/rigveda/index.htm) (M); [The Vishnu Purana](https://sacred-texts.com/hin/vp/index.htm) (M); [Dialogues of the Buddha (Digha Nikaya I)](https://sacred-texts.com/bud/dob/index.htm) (M); [Saddharma-pundarika (Lotus Sutra) SBE 21](https://sacred-texts.com/bud/lotus/index.htm) (M); [Jaina Sutras I (Akaranga & Kalpa Sutra) SBE 22](https://sacred-texts.com/jai/sbe22/index.htm) (M); [Myths and Legends of China](https://sacred-texts.com/cfu/mlc/index.htm) (M); [Kogoshui: Gleanings from Ancient Stories](https://sacred-texts.com/shi/kgsh/index.htm) (M); [Aino Folk-Tales](https://sacred-texts.com/shi/aft/index.htm) (M); [A Journey in Southern Siberia](https://sacred-texts.com/asia/jss/index.htm) (M); [The Popol Vuh (excerpt)](https://sacred-texts.com/nam/pvuheng.htm) (M); [Legends and Myths of the Aboriginal Indians of British Guiana](https://sacred-texts.com/nam/sa/lmbg/index.htm) (M); [Tales and Traditions of the Eskimo](https://sacred-texts.com/nam/inu/tte/index.htm) (M); [Pueblo Indian Folk-Stories](https://sacred-texts.com/nam/sw/pifs/index.htm) (M); [The Book of Chilam Balam of Chumayel](https://sacred-texts.com/nam/maya/cbc/index.htm) (M); [Polynesian Mythology](https://sacred-texts.com/pac/grey/index.htm) (M); [Hawaiian Mythology](https://sacred-texts.com/pac/hm/index.htm) (M); [Oceanic Mythology](https://sacred-texts.com/pac/om/index.htm) (M); [Maori Religion and Mythology](https://sacred-texts.com/pac/mrm/index.htm) (M); [The Samoan Story of Creation](https://sacred-texts.com/pac/jpolys/ssc.htm) (M); [The Prose Edda](https://sacred-texts.com/neu/pre/index.htm) (M); [Aradia, or the Gospel of the Witches](https://sacred-texts.com/pag/aradia/index.htm) (M); [Who are the Ufonauts? (Book of Enoch) [BBS file]](https://sacred-texts.com/ufo/nephilim.htm) (M); [Flying Saucers: The Bible Connection [BBS file]](https://sacred-texts.com/ufo/bibleufo.htm) (M); [Review of 'The 12th Planet' [BBS file]](https://sacred-texts.com/ufo/sitchin.htm) (M)

### CULT: Culture-bringer: non-human teacher gives arts, law, agriculture, writing, kingship

[Myths and Legends of the Bantu](https://sacred-texts.com/afr/mlb/index.htm) (H); [Myths of Ife](https://sacred-texts.com/afr/ife/index.htm) (H); [Sumerian Mythology](https://sacred-texts.com/ane/sum/index.htm) (H); [The Seven Tablets of Creation (Enuma Elish)](https://sacred-texts.com/ane/stc/index.htm) (H); [Myths and Legends of Babylonia and Assyria](https://sacred-texts.com/ane/mba/index.htm) (H); [Adapa and the Food of Life](https://sacred-texts.com/ane/adapa.htm) (H); [The Book of Jubilees](https://sacred-texts.com/bib/jub/index.htm) (H); [The Kojiki](https://sacred-texts.com/shi/kj/index.htm) (H); [Tales of the North American Indians](https://sacred-texts.com/nam/tnai/index.htm) (H); [Traditions of the Hopi](https://sacred-texts.com/nam/hopi/toth/index.htm) (H); [Blackfoot Lodge Tales](https://sacred-texts.com/nam/pla/blt/index.htm) (H); [The Myths of Mexico and Peru](https://sacred-texts.com/nam/mmp/index.htm) (H); [Viracocha and the Coming of the Incas](https://sacred-texts.com/nam/inca/inca01.htm) (H); [Chinigchinich (Boscana)](https://sacred-texts.com/nam/ca/bosc/index.htm) (H); [The Lore of the Whare-Wananga](https://sacred-texts.com/pac/lww/index.htm) (H); [The Euahlayi Tribe](https://sacred-texts.com/aus/tet/index.htm) (H); [Australian Legendary Tales](https://sacred-texts.com/aus/alt/index.htm) (H); [Ancient Fragments (Cory)](https://sacred-texts.com/cla/af/index.htm) (H); [Gods and Fighting Men](https://sacred-texts.com/neu/celt/gafm/index.htm) (H); [The Second Battle of Mag Tuired (Cath Maige Tuired)](https://sacred-texts.com/neu/cmt/cmteng.htm) (H); [The Poetic Edda](https://sacred-texts.com/neu/poe/index.htm) (H); [The Secret Doctrine](https://sacred-texts.com/the/sd/index.htm) (H); [A Textbook of Theosophy](https://sacred-texts.com/the/tot/index.htm) (H); [Initiation, Human and Solar](https://sacred-texts.com/eso/ihas/index.htm) (H); [The Story of Atlantis](https://sacred-texts.com/atl/soa/index.htm) (H); [The Lost Lemuria](https://sacred-texts.com/atl/tll/index.htm) (H); [The Religious System of the Amazulu](https://sacred-texts.com/afr/rsa/index.htm) (M); [The Yoruba Speaking Peoples](https://sacred-texts.com/afr/yor/index.htm) (M); [Yoruba Legends](https://sacred-texts.com/afr/yl/index.htm) (M); [The Babylonian Legends of Creation](https://sacred-texts.com/ane/blc/index.htm) (M); [Legends of Babylonia and Egypt in Relation to Hebrew Tradition](https://sacred-texts.com/ane/beheb.htm) (M); [Legends of the Gods: The Egyptian Texts](https://sacred-texts.com/egy/leg/index.htm) (M); [Egyptian Myth and Legend](https://sacred-texts.com/egy/eml/index.htm) (M); [The Works of Flavius Josephus](https://sacred-texts.com/jud/josephus/index.htm) (M); [Thrice-Greatest Hermes (3 vols)](https://sacred-texts.com/gno/th1/index.htm) (M); [The Virgin of the World (Kore Kosmou)](https://sacred-texts.com/eso/vow/index.htm) (M); [The Zend Avesta I: Vendidad (SBE 4)](https://sacred-texts.com/zor/sbe04/index.htm) (M); [The Rig-Veda](https://sacred-texts.com/hin/rigveda/index.htm) (M); [Satapatha Brahmana (SBE 12, 26, 41, 43, 44)](https://sacred-texts.com/hin/sbr/index.htm) (M); [Aino Folk-Tales](https://sacred-texts.com/shi/aft/index.htm) (M); [A Journey in Southern Siberia](https://sacred-texts.com/asia/jss/index.htm) (M); [The Old North Trail](https://sacred-texts.com/nam/pla/ont/index.htm) (M); [Origin Myths of the Navaho Indians](https://sacred-texts.com/nam/nav/omni/index.htm) (M); [Navajo Creation Myth](https://sacred-texts.com/nam/nav/ncm/index.htm) (M); [Origin Myth of Acoma](https://sacred-texts.com/nam/sw/oma/index.htm) (M); [The Algonquin Legends of New England](https://sacred-texts.com/nam/ne/al/index.htm) (M); [The Sun Dance and Other Ceremonies of the Oglala](https://sacred-texts.com/nam/pla/sdo/index.htm) (M); [Oceanic Mythology](https://sacred-texts.com/pac/om/index.htm) (M); [Legends of Maui](https://sacred-texts.com/pac/maui/index.htm) (M); [The Native Tribes of Central Australia](https://sacred-texts.com/aus/ntca/index.htm) (M); [Critias (with Timaeus)](https://sacred-texts.com/cla/plato/critias.htm) (M); [Celtic Myth and Legend](https://sacred-texts.com/neu/celt/cml/index.htm) (M); [Myths and Legends of the Celtic Race](https://sacred-texts.com/neu/celt/mlcr/index.htm) (M); [The Prose Edda](https://sacred-texts.com/neu/pre/index.htm) (M); [Heimskringla (Ynglinga Saga)](https://sacred-texts.com/neu/heim/index.htm) (M); [Atlantis, the Antediluvian World](https://sacred-texts.com/atl/ataw/index.htm) (M); [The Secret Teachings of All Ages](https://sacred-texts.com/eso/sta/index.htm) (M); [Aradia, or the Gospel of the Witches](https://sacred-texts.com/pag/aradia/index.htm) (M); [The Dogon [BBS file]](https://sacred-texts.com/ufo/dogon.htm) (M); [Review of 'The 12th Planet' [BBS file]](https://sacred-texts.com/ufo/sitchin.htm) (M)

### FORB: Forbidden knowledge transfer (Watchers/Azazel, Harut & Marut, Prometheus-type theft)

[The Kebra Nagast](https://sacred-texts.com/afr/kn/index.htm) (H); [Sumerian Mythology](https://sacred-texts.com/ane/sum/index.htm) (H); [The Book of Enoch](https://sacred-texts.com/bib/boe/index.htm) (H); [The Book of Enoch the Prophet](https://sacred-texts.com/bib/bep/index.htm) (H); [The Book of Jubilees](https://sacred-texts.com/bib/jub/index.htm) (H); [The Forgotten Books of Eden (incl. 2 Enoch)](https://sacred-texts.com/bib/fbe/index.htm) (H); [Legends of the Jews](https://sacred-texts.com/jud/loj/index.htm) (H); [The Book of Giants (Manichaean)](https://sacred-texts.com/chr/giants/giants.htm) (H); [The Holy Quran (Yusuf Ali)](https://sacred-texts.com/isl/yaq/index.htm) (H); [The Bible, the Koran, and the Talmud (Biblical Legends of the Mussulmans)](https://sacred-texts.com/isl/bkt/index.htm) (H); [The Lore of the Whare-Wananga](https://sacred-texts.com/pac/lww/index.htm) (H); [Ancient Fragments (Cory)](https://sacred-texts.com/cla/af/index.htm) (H); [The Zohar: Bereshith to Lekh Lekha](https://sacred-texts.com/jud/zdm/index.htm) (M); [Pistis Sophia](https://sacred-texts.com/chr/ps/index.htm) (M); [Hypertext Qur'an (all translations)](https://sacred-texts.com/isl/htq/index.htm) (M); [Hesiod's Theogony](https://sacred-texts.com/cla/hesiod/theogony.htm) (M); [Works and Days](https://sacred-texts.com/cla/hesiod/works.htm) (M); [The Sibylline Oracles](https://sacred-texts.com/cla/sib/index.htm) (M); [The Shah Namah](https://sacred-texts.com/neu/shahnama.txt) (M); [Who are the Ufonauts? (Book of Enoch) [BBS file]](https://sacred-texts.com/ufo/nephilim.htm) (M)

### HYB: Hybrid offspring / divine-human unions / embryo transfer / changelings

[Myths and Legends of the Bantu](https://sacred-texts.com/afr/mlb/index.htm) (H); [The Kebra Nagast](https://sacred-texts.com/afr/kn/index.htm) (H); [The Book of Enoch](https://sacred-texts.com/bib/boe/index.htm) (H); [The Book of Enoch the Prophet](https://sacred-texts.com/bib/bep/index.htm) (H); [The Book of Jubilees](https://sacred-texts.com/bib/jub/index.htm) (H); [King James Bible: Genesis 6](https://sacred-texts.com/bib/kjv/gen006.htm) (H); [Legends of the Jews](https://sacred-texts.com/jud/loj/index.htm) (H); [The Book of Giants (Manichaean)](https://sacred-texts.com/chr/giants/giants.htm) (H); [The Mahabharata (Ganguli)](https://sacred-texts.com/hin/maha/index.htm) (H); [The Kojiki](https://sacred-texts.com/shi/kj/index.htm) (H); [Nihongi (Part 1 of 4)](https://sacred-texts.com/shi/nihon0.htm) (H); [Tales of the North American Indians](https://sacred-texts.com/nam/tnai/index.htm) (H); [Blackfoot Lodge Tales](https://sacred-texts.com/nam/pla/blt/index.htm) (H); [Ancient Fragments (Cory)](https://sacred-texts.com/cla/af/index.htm) (H); [The Fairy-Faith in Celtic Countries](https://sacred-texts.com/neu/celt/ffcc/index.htm) (H); [The Secret Common-Wealth of Elves, Fauns and Fairies](https://sacred-texts.com/neu/celt/sce/index.htm) (H); [The Second Battle of Mag Tuired (Cath Maige Tuired)](https://sacred-texts.com/neu/cmt/cmteng.htm) (H); [The Science of Fairy Tales](https://sacred-texts.com/neu/celt/sft/index.htm) (H); [The Poetic Edda](https://sacred-texts.com/neu/poe/index.htm) (H); [The Secret Doctrine](https://sacred-texts.com/the/sd/index.htm) (H); [The Book of Dzyan (excerpt)](https://sacred-texts.com/atl/dzyan/dzyan.htm) (H); [Comte de Gabalis](https://sacred-texts.com/eso/cdg/index.htm) (H); [Oahspe, A Kosmon Bible](https://sacred-texts.com/oah/oah/index.htm) (H); [Other Tongues--Other Flesh](https://sacred-texts.com/ufo/otof/index.htm) (H); [I Remember Lemuria](https://sacred-texts.com/ufo/irl/index.htm) (H); [The Epic of Gilgamish](https://sacred-texts.com/ane/eog/index.htm) (M); [Legends of Babylonia and Egypt in Relation to Hebrew Tradition](https://sacred-texts.com/ane/beheb.htm) (M); [The Biblical Antiquities of Philo](https://sacred-texts.com/bib/bap/index.htm) (M); [The Works of Flavius Josephus](https://sacred-texts.com/jud/josephus/index.htm) (M); [The Zohar: Bereshith to Lekh Lekha](https://sacred-texts.com/jud/zdm/index.htm) (M); [The Book of the Cave of Treasures](https://sacred-texts.com/chr/bct/index.htm) (M); [The Book of the Bee](https://sacred-texts.com/chr/bb/index.htm) (M); [The Book of Jasher](https://sacred-texts.com/chr/apo/jasher/index.htm) (M); [Hindu Mythology, Vedic and Puranic](https://sacred-texts.com/hin/hmvp/index.htm) (M); [Jaina Sutras I (Akaranga & Kalpa Sutra) SBE 22](https://sacred-texts.com/jai/sbe22/index.htm) (M); [Shamanism in Siberia](https://sacred-texts.com/sha/sis/index.htm) (M); [Pueblo Indian Folk-Stories](https://sacred-texts.com/nam/sw/pifs/index.htm) (M); [Polynesian Mythology](https://sacred-texts.com/pac/grey/index.htm) (M); [The Kumulipo](https://sacred-texts.com/pac/ku/index.htm) (M); [Works and Days](https://sacred-texts.com/cla/hesiod/works.htm) (M); [Critias (with Timaeus)](https://sacred-texts.com/cla/plato/critias.htm) (M); [The Sibylline Oracles](https://sacred-texts.com/cla/sib/index.htm) (M); [Celtic Folklore: Welsh and Manx](https://sacred-texts.com/neu/cfwm/index.htm) (M); [Heroic Romances of Ireland](https://sacred-texts.com/neu/hroi/index.htm) (M); [Fairy and Folk Tales of the Irish Peasantry](https://sacred-texts.com/neu/yeats/fip/index.htm) (M); [Cuchulain of Muirthemne](https://sacred-texts.com/neu/celt/cuch/index.htm) (M); [Histories of the Kings of Britain](https://sacred-texts.com/neu/eng/gem/index.htm) (M); [Aradia, or the Gospel of the Witches](https://sacred-texts.com/pag/aradia/index.htm) (M); [Who are the Ufonauts? (Book of Enoch) [BBS file]](https://sacred-texts.com/ufo/nephilim.htm) (M); [Review of 'The 12th Planet' [BBS file]](https://sacred-texts.com/ufo/sitchin.htm) (M)

### VEH: Celestial vehicles: flying chariots, wagons, vimanas, sky-boats, 'airships', saucers

[The Kebra Nagast](https://sacred-texts.com/afr/kn/index.htm) (H); [King James Bible: Ezekiel 1](https://sacred-texts.com/bib/kjv/eze001.htm) (H); [The Mahabharata (Ganguli)](https://sacred-texts.com/hin/maha/index.htm) (H); [Ramayan of Valmiki](https://sacred-texts.com/hin/rama/index.htm) (H); [Nihongi (Part 1 of 4)](https://sacred-texts.com/shi/nihon0.htm) (H); [Comte de Gabalis](https://sacred-texts.com/eso/cdg/index.htm) (H); [Oahspe, A Kosmon Bible](https://sacred-texts.com/oah/oah/index.htm) (H); [The Secret of the Saucers](https://sacred-texts.com/ufo/sos/index.htm) (H); [Heaven's Gate](https://sacred-texts.com/ufo/hg/index.htm) (H); [The Pyramid Texts](https://sacred-texts.com/egy/pyt/index.htm) (M); [The Egyptian Book of the Dead](https://sacred-texts.com/egy/ebod/index.htm) (M); [The Book of Jasher](https://sacred-texts.com/chr/apo/jasher/index.htm) (M); [Hadith of Bukhari](https://sacred-texts.com/isl/bukhari/index.htm) (M); [The Arabian Nights (Burton)](https://sacred-texts.com/neu/burt1k1/index.htm) (M); [The Rig-Veda](https://sacred-texts.com/hin/rigveda/index.htm) (M); [Jaina Sutras I (Akaranga & Kalpa Sutra) SBE 22](https://sacred-texts.com/jai/sbe22/index.htm) (M); [The Shah Namah](https://sacred-texts.com/neu/shahnama.txt) (M); [A Dweller on Two Planets](https://sacred-texts.com/atl/dtp/index.htm) (M); [The Flying Saucers Are Real](https://sacred-texts.com/ufo/fsar/index.htm) (M); [Ancient Indian Aircraft Technology [BBS file]](https://sacred-texts.com/ufo/aiac.htm) (M); [Flying Aircraft and Nuclear War... of the Past [BBS file]](https://sacred-texts.com/ufo/ourpast.htm) (M); [Flying Saucers: The Bible Connection [BBS file]](https://sacred-texts.com/ufo/bibleufo.htm) (M); [New Lands](https://sacred-texts.com/fort/land/index.htm) (M); [The Book of the Damned](https://sacred-texts.com/fort/damn/index.htm) (M)

### STAR: Star-origin ancestry & star-people (Pleiades, Sirius, Morning Star, Venus)

[The Book of Enoch](https://sacred-texts.com/bib/boe/index.htm) (H); [Tales of the North American Indians](https://sacred-texts.com/nam/tnai/index.htm) (H); [Iroquoian Cosmology](https://sacred-texts.com/nam/iro/irc/index.htm) (H); [Myths of the Cherokee](https://sacred-texts.com/nam/cher/motc/index.htm) (H); [Traditions of the Hopi](https://sacred-texts.com/nam/hopi/toth/index.htm) (H); [Blackfoot Lodge Tales](https://sacred-texts.com/nam/pla/blt/index.htm) (H); [Viracocha and the Coming of the Incas](https://sacred-texts.com/nam/inca/inca01.htm) (H); [Chinigchinich (Boscana)](https://sacred-texts.com/nam/ca/bosc/index.htm) (H); [The Euahlayi Tribe](https://sacred-texts.com/aus/tet/index.htm) (H); [Australian Legendary Tales](https://sacred-texts.com/aus/alt/index.htm) (H); [The Secret Doctrine](https://sacred-texts.com/the/sd/index.htm) (H); [Specimens of Bushman Folklore](https://sacred-texts.com/afr/sbf/index.htm) (M); [The Pyramid Texts](https://sacred-texts.com/egy/pyt/index.htm) (M); [The Zend Avesta II: Sirozahs, Yasts (SBE 23)](https://sacred-texts.com/zor/sbe23/index.htm) (M); [Pahlavi Texts I: Bundahishn etc. (SBE 5)](https://sacred-texts.com/zor/sbe05/index.htm) (M); [Dialogues of the Buddha (Digha Nikaya I)](https://sacred-texts.com/bud/dob/index.htm) (M); [Chukchee Mythology](https://sacred-texts.com/asia/cm/index.htm) (M); [The Popol Vuh (excerpt)](https://sacred-texts.com/nam/pvuheng.htm) (M); [Seneca Indian Myths](https://sacred-texts.com/nam/iro/sim/index.htm) (M); [The Old North Trail](https://sacred-texts.com/nam/pla/ont/index.htm) (M); [Legends and Myths of the Aboriginal Indians of British Guiana](https://sacred-texts.com/nam/sa/lmbg/index.htm) (M); [Animism and Folk-Lore of the Guiana Indians](https://sacred-texts.com/nam/sa/aflg/index.htm) (M); [Navajo Creation Myth](https://sacred-texts.com/nam/nav/ncm/index.htm) (M); [The Sun Dance and Other Ceremonies of the Oglala](https://sacred-texts.com/nam/pla/sdo/index.htm) (M); [Pearl of Great Price](https://sacred-texts.com/mor/pgp/index.htm) (M); [The Dogon [BBS file]](https://sacred-texts.com/ufo/dogon.htm) (M)

### TIME: Otherworld time dilation (years pass in hours; return to dust)

[The Fairy-Faith in Celtic Countries](https://sacred-texts.com/neu/celt/ffcc/index.htm) (H); [Gods and Fighting Men](https://sacred-texts.com/neu/celt/gafm/index.htm) (H); [The Voyage of Bran](https://sacred-texts.com/neu/celt/vob/index.htm) (H); [The Science of Fairy Tales](https://sacred-texts.com/neu/celt/sft/index.htm) (H); [Celtic Folklore: Welsh and Manx](https://sacred-texts.com/neu/cfwm/index.htm) (M); [British Goblins](https://sacred-texts.com/neu/celt/wfl/index.htm) (M); [Tales of the Enchanted Islands of the Atlantic](https://sacred-texts.com/earth/teia/index.htm) (M)

### ABD: Abduction / otherworld journey / ascent to sky-world and return

[Myths and Legends of the Bantu](https://sacred-texts.com/afr/mlb/index.htm) (H); [Myths and Legends of Babylonia and Assyria](https://sacred-texts.com/ane/mba/index.htm) (H); [Adapa and the Food of Life](https://sacred-texts.com/ane/adapa.htm) (H); [The Book of Enoch](https://sacred-texts.com/bib/boe/index.htm) (H); [The Book of Enoch the Prophet](https://sacred-texts.com/bib/bep/index.htm) (H); [The Forgotten Books of Eden (incl. 2 Enoch)](https://sacred-texts.com/bib/fbe/index.htm) (H); [Legends of the Jews](https://sacred-texts.com/jud/loj/index.htm) (H); [The Holy Quran (Yusuf Ali)](https://sacred-texts.com/isl/yaq/index.htm) (H); [The Bible, the Koran, and the Talmud (Biblical Legends of the Mussulmans)](https://sacred-texts.com/isl/bkt/index.htm) (H); [The Mahabharata (Ganguli)](https://sacred-texts.com/hin/maha/index.htm) (H); [Tales of the North American Indians](https://sacred-texts.com/nam/tnai/index.htm) (H); [Myths of the Cherokee](https://sacred-texts.com/nam/cher/motc/index.htm) (H); [Blackfoot Lodge Tales](https://sacred-texts.com/nam/pla/blt/index.htm) (H); [The Lore of the Whare-Wananga](https://sacred-texts.com/pac/lww/index.htm) (H); [The Fairy-Faith in Celtic Countries](https://sacred-texts.com/neu/celt/ffcc/index.htm) (H); [The Secret Common-Wealth of Elves, Fauns and Fairies](https://sacred-texts.com/neu/celt/sce/index.htm) (H); [Gods and Fighting Men](https://sacred-texts.com/neu/celt/gafm/index.htm) (H); [The Voyage of Bran](https://sacred-texts.com/neu/celt/vob/index.htm) (H); [The Science of Fairy Tales](https://sacred-texts.com/neu/celt/sft/index.htm) (H); [The Secret of the Saucers](https://sacred-texts.com/ufo/sos/index.htm) (H); [Notes on the Folklore of the Fjort](https://sacred-texts.com/afr/fjort/index.htm) (M); [Drums and Shadows](https://sacred-texts.com/afr/das/index.htm) (M); [The Epic of Gilgamish](https://sacred-texts.com/ane/eog/index.htm) (M); [The Pyramid Texts](https://sacred-texts.com/egy/pyt/index.htm) (M); [The Egyptian Book of the Dead](https://sacred-texts.com/egy/ebod/index.htm) (M); [The Book of Jasher](https://sacred-texts.com/chr/apo/jasher/index.htm) (M); [Hadith of Bukhari](https://sacred-texts.com/isl/bukhari/index.htm) (M); [The Arabian Nights (Burton)](https://sacred-texts.com/neu/burt1k1/index.htm) (M); [Indian Myth and Legend](https://sacred-texts.com/hin/iml/index.htm) (M); [Myths and Legends of China](https://sacred-texts.com/cfu/mlc/index.htm) (M); [Chukchee Mythology](https://sacred-texts.com/asia/cm/index.htm) (M); [Shamanism in Siberia](https://sacred-texts.com/sha/sis/index.htm) (M); [Seneca Indian Myths](https://sacred-texts.com/nam/iro/sim/index.htm) (M); [Tales and Traditions of the Eskimo](https://sacred-texts.com/nam/inu/tte/index.htm) (M); [The Code of Handsome Lake](https://sacred-texts.com/nam/iro/parker/index.htm) (M); [Polynesian Mythology](https://sacred-texts.com/pac/grey/index.htm) (M); [A True Story (Lucian)](https://sacred-texts.com/cla/luc/true/index.htm) (M); [The Fairy Mythology](https://sacred-texts.com/neu/celt/tfm/index.htm) (M); [Visions and Beliefs in the West of Ireland](https://sacred-texts.com/neu/celt/vbwi/index.htm) (M); [Heroic Romances of Ireland](https://sacred-texts.com/neu/hroi/index.htm) (M); [The Mabinogion](https://sacred-texts.com/neu/celt/mab/index.htm) (M); [My Trip to Mars](https://sacred-texts.com/ufo/mars/mttm/index.htm) (M); [Tales of the Enchanted Islands of the Atlantic](https://sacred-texts.com/earth/teia/index.htm) (M)

### PLUR: Plurality of inhabited worlds / beings from other planets

[The Secret Doctrine](https://sacred-texts.com/the/sd/index.htm) (H); [A Textbook of Theosophy](https://sacred-texts.com/the/tot/index.htm) (H); [Initiation, Human and Solar](https://sacred-texts.com/eso/ihas/index.htm) (H); [The Story of Atlantis](https://sacred-texts.com/atl/soa/index.htm) (H); [The Lost Lemuria](https://sacred-texts.com/atl/tll/index.htm) (H); [Unveiled Mysteries](https://sacred-texts.com/eso/um/index.htm) (H); [Earths in the Universe](https://sacred-texts.com/swd/eiu/index.htm) (H); [From India to the Planet Mars](https://sacred-texts.com/ufo/ipm/index.htm) (H); [Other Tongues--Other Flesh](https://sacred-texts.com/ufo/otof/index.htm) (H); [We Met the Space People](https://sacred-texts.com/ufo/wmsp/index.htm) (H); [In Days To Come](https://sacred-texts.com/ufo/idtc/index.htm) (H); [I Remember Lemuria](https://sacred-texts.com/ufo/irl/index.htm) (H); [Dialogues of the Buddha (Digha Nikaya I)](https://sacred-texts.com/bud/dob/index.htm) (M); [Saddharma-pundarika (Lotus Sutra) SBE 21](https://sacred-texts.com/bud/lotus/index.htm) (M); [A True Story (Lucian)](https://sacred-texts.com/cla/luc/true/index.htm) (M); [A Dweller on Two Planets](https://sacred-texts.com/atl/dtp/index.htm) (M); [Heaven and Hell](https://sacred-texts.com/swd/hh/index.htm) (M); [Pearl of Great Price](https://sacred-texts.com/mor/pgp/index.htm) (M); [The Flying Saucers Are Real](https://sacred-texts.com/ufo/fsar/index.htm) (M); [The Planet Mars and its Inhabitants](https://sacred-texts.com/ufo/mars/mah/index.htm) (M); [My Trip to Mars](https://sacred-texts.com/ufo/mars/mttm/index.htm) (M); [New Lands](https://sacred-texts.com/fort/land/index.htm) (M); [The Book of the Damned](https://sacred-texts.com/fort/damn/index.htm) (M)

### DIM: Other planes/dimensions: fairy, elemental, subterranean or parallel hidden peoples

[Myths and Legends of Babylonia and Assyria](https://sacred-texts.com/ane/mba/index.htm) (H); [The Holy Quran (Yusuf Ali)](https://sacred-texts.com/isl/yaq/index.htm) (H); [The Bible, the Koran, and the Talmud (Biblical Legends of the Mussulmans)](https://sacred-texts.com/isl/bkt/index.htm) (H); [Ramayan of Valmiki](https://sacred-texts.com/hin/rama/index.htm) (H); [Myths of the Cherokee](https://sacred-texts.com/nam/cher/motc/index.htm) (H); [Traditions of the Hopi](https://sacred-texts.com/nam/hopi/toth/index.htm) (H); [The Fairy-Faith in Celtic Countries](https://sacred-texts.com/neu/celt/ffcc/index.htm) (H); [The Secret Common-Wealth of Elves, Fauns and Fairies](https://sacred-texts.com/neu/celt/sce/index.htm) (H); [Gods and Fighting Men](https://sacred-texts.com/neu/celt/gafm/index.htm) (H); [The Voyage of Bran](https://sacred-texts.com/neu/celt/vob/index.htm) (H); [The Science of Fairy Tales](https://sacred-texts.com/neu/celt/sft/index.htm) (H); [Comte de Gabalis](https://sacred-texts.com/eso/cdg/index.htm) (H); [I Remember Lemuria](https://sacred-texts.com/ufo/irl/index.htm) (H); [Pistis Sophia](https://sacred-texts.com/chr/ps/index.htm) (M); [Fragments of a Faith Forgotten](https://sacred-texts.com/gno/fff/index.htm) (M); [Hypertext Qur'an (all translations)](https://sacred-texts.com/isl/htq/index.htm) (M); [Hadith of Bukhari](https://sacred-texts.com/isl/bukhari/index.htm) (M); [Folk-lore of the Holy Land](https://sacred-texts.com/asia/flhl/index.htm) (M); [The Arabian Nights (Burton)](https://sacred-texts.com/neu/burt1k1/index.htm) (M); [The Vishnu Purana](https://sacred-texts.com/hin/vp/index.htm) (M); [Hindu Mythology, Vedic and Puranic](https://sacred-texts.com/hin/hmvp/index.htm) (M); [Indian Myth and Legend](https://sacred-texts.com/hin/iml/index.htm) (M); [Animism and Folk-Lore of the Guiana Indians](https://sacred-texts.com/nam/sa/aflg/index.htm) (M); [Origin Myths of the Navaho Indians](https://sacred-texts.com/nam/nav/omni/index.htm) (M); [The Algonquin Legends of New England](https://sacred-texts.com/nam/ne/al/index.htm) (M); [Hawaiian Mythology](https://sacred-texts.com/pac/hm/index.htm) (M); [The Native Tribes of Central Australia](https://sacred-texts.com/aus/ntca/index.htm) (M); [The Fairy Mythology](https://sacred-texts.com/neu/celt/tfm/index.htm) (M); [Celtic Folklore: Welsh and Manx](https://sacred-texts.com/neu/cfwm/index.htm) (M); [Visions and Beliefs in the West of Ireland](https://sacred-texts.com/neu/celt/vbwi/index.htm) (M); [Heroic Romances of Ireland](https://sacred-texts.com/neu/hroi/index.htm) (M); [Celtic Myth and Legend](https://sacred-texts.com/neu/celt/cml/index.htm) (M); [Myths and Legends of the Celtic Race](https://sacred-texts.com/neu/celt/mlcr/index.htm) (M); [The Religion of the Ancient Celts](https://sacred-texts.com/neu/celt/rac/index.htm) (M); [The Mabinogion](https://sacred-texts.com/neu/celt/mab/index.htm) (M); [British Goblins](https://sacred-texts.com/neu/celt/wfl/index.htm) (M); [Fairy and Folk Tales of the Irish Peasantry](https://sacred-texts.com/neu/yeats/fip/index.htm) (M); [The Celtic Twilight](https://sacred-texts.com/neu/yeats/twi/index.htm) (M); [The Candle of Vision](https://sacred-texts.com/neu/celt/cov/index.htm) (M); [Cuchulain of Muirthemne](https://sacred-texts.com/neu/celt/cuch/index.htm) (M); [The Coming of the Fairies](https://sacred-texts.com/neu/eng/cof/index.htm) (M); [Isis Unveiled](https://sacred-texts.com/the/iu/index.htm) (M); [Vril, the Power of the Coming Race](https://sacred-texts.com/atl/vril/index.htm) (M); [Enochian Magic section & The Calls of Enoch](https://sacred-texts.com/eso/enoch/index.htm) (M); [The Secret Teachings of All Ages](https://sacred-texts.com/eso/sta/index.htm) (M); [Heaven and Hell](https://sacred-texts.com/swd/hh/index.htm) (M); [A Brief Account of the True Nature of the UFO Entities [BBS file]](https://sacred-texts.com/ufo/jinns.htm) (M); [Tales of the Enchanted Islands of the Atlantic](https://sacred-texts.com/earth/teia/index.htm) (M)

### CHAN: Channeled / contactee communication with non-human intelligences

[Initiation, Human and Solar](https://sacred-texts.com/eso/ihas/index.htm) (H); [Unveiled Mysteries](https://sacred-texts.com/eso/um/index.htm) (H); [Oahspe, A Kosmon Bible](https://sacred-texts.com/oah/oah/index.htm) (H); [Earths in the Universe](https://sacred-texts.com/swd/eiu/index.htm) (H); [From India to the Planet Mars](https://sacred-texts.com/ufo/ipm/index.htm) (H); [Other Tongues--Other Flesh](https://sacred-texts.com/ufo/otof/index.htm) (H); [The Secret of the Saucers](https://sacred-texts.com/ufo/sos/index.htm) (H); [We Met the Space People](https://sacred-texts.com/ufo/wmsp/index.htm) (H); [In Days To Come](https://sacred-texts.com/ufo/idtc/index.htm) (H); [Heaven's Gate](https://sacred-texts.com/ufo/hg/index.htm) (H); [The Code of Handsome Lake](https://sacred-texts.com/nam/iro/parker/index.htm) (M); [The Candle of Vision](https://sacred-texts.com/neu/celt/cov/index.htm) (M); [A Dweller on Two Planets](https://sacred-texts.com/atl/dtp/index.htm) (M); [Enochian Magic section & The Calls of Enoch](https://sacred-texts.com/eso/enoch/index.htm) (M); [Liber AL vel Legis (The Book of the Law)](https://sacred-texts.com/oto/engccxx.htm) (M); [The Amalantrah Working (Soror Achitha's Vision)](https://sacred-texts.com/oto/lib97.txt) (M); [The Planet Mars and its Inhabitants](https://sacred-texts.com/ufo/mars/mah/index.htm) (M); [My Trip to Mars](https://sacred-texts.com/ufo/mars/mttm/index.htm) (M)

### WAR: War or rebellion among sky beings; fallen/expelled beings

[Myths of Ife](https://sacred-texts.com/afr/ife/index.htm) (H); [The Kebra Nagast](https://sacred-texts.com/afr/kn/index.htm) (H); [The Seven Tablets of Creation (Enuma Elish)](https://sacred-texts.com/ane/stc/index.htm) (H); [The Book of Enoch](https://sacred-texts.com/bib/boe/index.htm) (H); [Legends of the Jews](https://sacred-texts.com/jud/loj/index.htm) (H); [The Book of Giants (Manichaean)](https://sacred-texts.com/chr/giants/giants.htm) (H); [The Bible, the Koran, and the Talmud (Biblical Legends of the Mussulmans)](https://sacred-texts.com/isl/bkt/index.htm) (H); [The Mahabharata (Ganguli)](https://sacred-texts.com/hin/maha/index.htm) (H); [The Second Battle of Mag Tuired (Cath Maige Tuired)](https://sacred-texts.com/neu/cmt/cmteng.htm) (H); [The Enuma Elish (single-page text)](https://sacred-texts.com/ane/enuma.htm) (M); [The Book of the Bee](https://sacred-texts.com/chr/bb/index.htm) (M); [The Zend Avesta II: Sirozahs, Yasts (SBE 23)](https://sacred-texts.com/zor/sbe23/index.htm) (M); [Pahlavi Texts I: Bundahishn etc. (SBE 5)](https://sacred-texts.com/zor/sbe05/index.htm) (M); [The Rig-Veda](https://sacred-texts.com/hin/rigveda/index.htm) (M); [Hesiod's Theogony](https://sacred-texts.com/cla/hesiod/theogony.htm) (M); [A True Story (Lucian)](https://sacred-texts.com/cla/luc/true/index.htm) (M); [Flying Aircraft and Nuclear War... of the Past [BBS file]](https://sacred-texts.com/ufo/ourpast.htm) (M)

## 2. High-relevance texts (all)

| Category | Title | Author/translator, year | Type | Motifs | Why |
|---|---|---|---|---|---|
| African | [Myths and Legends of the Bantu](https://sacred-texts.com/afr/mlb/index.htm) | Alice Werner, 1933 | S | SKY ABD HYB CULT | Chapters 'The Heaven Country and the Heaven People', 'Mortals Who Have Ascended to Heaven', 'Legends of the High Gods', half-men: best African source for sky-people and sky-journeys. |
| African | [Myths of Ife](https://sacred-texts.com/afr/ife/index.htm) | John Wyndham, 1921 | P | SKY CULT WAR | Yoruba cosmogony in verse: 'The Descent' of the gods from the sky to found Ife; 'The War of the Gods'. |
| African | [The Kebra Nagast](https://sacred-texts.com/afr/kn/index.htm) | tr. E.A. Wallis Budge, 1922 | P | VEH FORB HYB WAR | Ethiopian epic: Solomon's son's wagon flies 'a cubit above the earth' carrying the Ark (ch. 52-53), chariot chapters 113-117 (CORRECTED 2026-09-26: here 'chariot' is a royal palladium; no flight is described), and ch. 100 'Concerning the Angels who rebelled' (Watchers, daughters of Cain, giants). |
| Ancient Near East | [Sumerian Mythology](https://sacred-texts.com/ane/sum/index.htm) | Samuel Noah Kramer, 1944/1961 | S | CULT SKY FORB | Scholarly source for the Anunnaki, Enki's 'me' (arts of civilization) transferred to Inanna, creation of humans to serve the gods, Kur. |
| Ancient Near East | [The Seven Tablets of Creation (Enuma Elish)](https://sacred-texts.com/ane/stc/index.htm) | L.W. King, 1902 | P | SKY WAR CULT | Marduk assigns the Anunnaki of heaven and earth; humans created from Kingu's blood to relieve the gods' labour. |
| Ancient Near East | [Myths and Legends of Babylonia and Assyria](https://sacred-texts.com/ane/mba/index.htm) | Donald A. Mackenzie, 1915 | S | CULT ABD SKY DIM | Ea/Oannes as 'God of the Deep' who taught the arts, Etana's eagle-flight to heaven, Adapa, 'Demons, Fairies, and Ghosts', astrology. |
| Ancient Near East | [Adapa and the Food of Life](https://sacred-texts.com/ane/adapa.htm) | R.W. Rogers, 1912 | P | ABD CULT | Adapa, first of the Apkallu sages of Eridu, summoned up to Anu's heaven and offered immortality. |
| Bible | [The Book of Enoch](https://sacred-texts.com/bib/boe/index.htm) | tr. R.H. Charles, 1917 | P | SKY FORB HYB ABD WAR STAR | Watchers descend on Mt Hermon, take human wives, beget the Nephilim, teach metallurgy, cosmetics, sorcery and astrology (Azazel, Shemihaza); Enoch's heavenly journeys and astronomical book. |
| Bible | [The Book of Enoch the Prophet](https://sacred-texts.com/bib/bep/index.htm) | tr. Richard Laurence, 1883 | P | SKY FORB HYB ABD | Earlier translation from the Ethiopic (1 Enoch is canonical in the Ethiopian Orthodox church - African link). |
| Bible | [The Book of Jubilees](https://sacred-texts.com/bib/jub/index.htm) | tr. R.H. Charles, 1917 | P | FORB HYB CULT | Watchers first sent down to instruct humanity, then fall; giants; Kainan finds the Watchers' astrological inscriptions. |
| Bible | [The Forgotten Books of Eden (incl. 2 Enoch)](https://sacred-texts.com/bib/fbe/index.htm) | ed. Rutherford H. Platt, 1926 | P | ABD SKY FORB | 2 Enoch: Enoch carried through the heavens by two huge shining men; Grigori (Watchers); Adam and Eve books. |
| Bible | [King James Bible: Genesis 6](https://sacred-texts.com/bib/kjv/gen006.htm) | KJV, 1611 | P | HYB SKY | 'Sons of God' take the daughters of men; Nephilim/giants - the canonical seed text. |
| Bible | [King James Bible: Ezekiel 1](https://sacred-texts.com/bib/kjv/eze001.htm) | KJV, 1611 | P | VEH SKY | Merkabah vision of living creatures and 'wheels within wheels' - the most-cited celestial-vehicle passage. |
| Judaism | [Legends of the Jews](https://sacred-texts.com/jud/loj/index.htm) | Louis Ginzberg, 1909 | S | FORB HYB ABD SKY WAR | Midrash compendium: Shemhazai and Azazel, Naamah, giants, Enoch translated to heaven as Metatron, angels teaching arts. |
| Gnosticism / Hermetica | [The Book of Giants (Manichaean)](https://sacred-texts.com/chr/giants/giants.htm) | tr. W.B. Henning, 1943 | P | HYB FORB WAR | Fragments on the Watchers' giant sons (Ohya, Mahaway) and their dreams: Enochic tradition in Central Asia. |
| Islam | [The Holy Quran (Yusuf Ali)](https://sacred-texts.com/isl/yaq/index.htm) | Abdullah Yusuf Ali, 1934 | P | DIM FORB ABD | Jinn as a separate intelligent species (Surah 72 al-Jinn; 55; 46:29), Harut & Marut teaching sorcery at Babylon (2:102), Idris raised high (19:56-57). |
| Islam | [The Bible, the Koran, and the Talmud (Biblical Legends of the Mussulmans)](https://sacred-texts.com/isl/bkt/index.htm) | Gustav Weil, 1863 | S | FORB DIM ABD WAR | Idris/Enoch, jinn before Adam, angels' descent. (CORRECTED 2026-09-26: the fetched chapters (Adam, Idris, Solomon) do NOT contain a Harut & Marut narrative; that tale is Qur'an 2:102 plus tafsir.) |
| Hinduism | [The Mahabharata (Ganguli)](https://sacred-texts.com/hin/maha/index.htm) | tr. K.M. Ganguli, 1883-96 | P | VEH ABD WAR HYB | Vimanas of the gods; Salva's flying city Saubha (Vana Parva); Arjuna carried to Indra's heaven in Matali's chariot; celestial weapons. |
| Hinduism | [Ramayan of Valmiki](https://sacred-texts.com/hin/rama/index.htm) | Ralph T.H. Griffith, 1870-74 | P | VEH DIM | Pushpaka vimana (Ravana's aerial car) carries Rama home; rakshasas and vanaras as non-human peoples. |
| Shinto / Japan / Ainu | [The Kojiki](https://sacred-texts.com/shi/kj/index.htm) | Basil Hall Chamberlain, 1882 (1919 ed.) | P | SKY HYB CULT | Descent of the heavenly grandson Ninigi from Takamagahara via the Floating Bridge of Heaven; heavenly deities found the imperial line. |
| Shinto / Japan / Ainu | [Nihongi (Part 1 of 4)](https://sacred-texts.com/shi/nihon0.htm) | W.G. Aston, 1896 | P | SKY VEH HYB | Parallel accounts; Nigihayahi descends in the 'Heavenly Rock-Boat' (Ama-no-iwafune). |
| Native American | [Tales of the North American Indians](https://sacred-texts.com/nam/tnai/index.htm) | Stith Thompson, 1929 | S | STAR ABD HYB CULT | Comparative corpus incl. the 'Star Husband' tale (women taken to the sky as star-wives), 'Journeys to the Other World', culture heroes. |
| Native American | [Iroquoian Cosmology](https://sacred-texts.com/nam/iro/irc/index.htm) | J.N.B. Hewitt, 1903 | E | SKY STAR | Onondaga, Seneca and Mohawk versions of Sky Woman falling from the Sky World to found earth and humanity. |
| Native American | [Myths of the Cherokee](https://sacred-texts.com/nam/cher/motc/index.htm) | James Mooney, 1900 | E | STAR DIM ABD | 'What the Stars Are Like', 'Origin of the Pleiades and the Pine', 'The Milky Way', Nunnehi immortals, 'The Journey to the Sunrise'. |
| Native American | [Traditions of the Hopi](https://sacred-texts.com/nam/hopi/toth/index.htm) | H.R. Voth, 1905 | E | STAR CULT DIM | Emergence myth, katcinas who became stars, Spider Woman; supernatural teachers of the clans. |
| Native American | [Blackfoot Lodge Tales](https://sacred-texts.com/nam/pla/blt/index.htm) | George Bird Grinnell, 1892 | E | STAR ABD CULT HYB | 'Scarface' (journeys to Sun and Morning Star, brings the Sun Dance), 'The Lost Woman', 'The Theft from the Sun'. |
| Native American | [The Myths of Mexico and Peru](https://sacred-texts.com/nam/mmp/index.htm) | Lewis Spence, 1913 | S | CULT SKY | Quetzalcoatl and Viracocha as departing civilizing culture heroes; diffusionist-era survey. |
| Native American | [Viracocha and the Coming of the Incas](https://sacred-texts.com/nam/inca/inca01.htm) | (retelling), - | P | CULT SKY STAR | Children of the Sun sent to civilize humanity; Viracocha teacher-god. |
| Native American | [Chinigchinich (Boscana)](https://sacred-texts.com/nam/ca/bosc/index.htm) | Fr. Geronimo Boscana, tr. A. Robinson, 1846 | E | CULT STAR SKY | Acagchemem: Chinigchinich appeared, taught laws and ceremonies, then went up to the stars. |
| Pacific | [The Lore of the Whare-Wananga](https://sacred-texts.com/pac/lww/index.htm) | S. Percy Smith, 1913 | E | CULT FORB ABD SKY | Maori whare-wananga teaching: Tane ascends to the uppermost heaven and brings back the three baskets of knowledge; twelve heavens. |
| Australia | [The Euahlayi Tribe](https://sacred-texts.com/aus/tet/index.htm) | K. Langloh Parker, 1905 | E | CULT SKY STAR | Byamee (Baiame), the All-Father who lived on earth, gave laws and the Boorah, then went up to the sky; chapter 'Something About Stars and Legends'. |
| Australia | [Australian Legendary Tales](https://sacred-texts.com/aus/alt/index.htm) | K. Langloh Parker, 1897 | E | STAR CULT | 'Meamei the Seven Sisters' (Pleiades), 'Mullyangah the Morning Star', 'The Borah of Byamee'. |
| Classics | [Ancient Fragments (Cory)](https://sacred-texts.com/cla/af/index.htm) | I.P. Cory, 1832 | P | CULT FORB HYB | Berossus (via Polyhistor, Apollodorus, Abydenus): Oannes and the Annedoti, fish-man beings from the Erythraean Sea who taught letters, sciences and city-building; Sanchuniathon's Phoenician theology. |
| Celtic | [The Fairy-Faith in Celtic Countries](https://sacred-texts.com/neu/celt/ffcc/index.htm) | W.Y. Evans-Wentz, 1911 | E | DIM ABD TIME HYB | Field testimony from six Celtic lands on fairy encounters, abductions, 'People of the Goddess Dana', the Otherworld: key comparative source for abduction-lore parallels. |
| Celtic | [The Secret Common-Wealth of Elves, Fauns and Fairies](https://sacred-texts.com/neu/celt/sce/index.htm) | Robert Kirk (1691), comm. Andrew Lang, 1893 | P | DIM ABD HYB | 17th-c. minister's treatise on the 'subterranean inhabitants' of intermediate nature, second sight, abductions. |
| Celtic | [Gods and Fighting Men](https://sacred-texts.com/neu/celt/gafm/index.htm) | Lady Augusta Gregory, 1904 | P | CULT DIM ABD TIME | Tuatha De Danann arrival, Lugh master of all arts, Manannan's calls to Bran and Connla, Laegaire in the Happy Plain. |
| Celtic | [The Second Battle of Mag Tuired (Cath Maige Tuired)](https://sacred-texts.com/neu/cmt/cmteng.htm) | tr. Elizabeth A. Gray, 1982 (Irish Texts Society 52; CORRECTED: not Stokes 1891) | P | CULT WAR HYB SKY | Tuatha De Danann vs Fomorians; Lugh, the Dagda; half-Fomorian king Bres (in Lebor Gabala tradition the Tuatha arrive in dark clouds). |
| Celtic | [The Voyage of Bran](https://sacred-texts.com/neu/celt/vob/index.htm) | Kuno Meyer, 1895 | P | TIME ABD DIM | An otherworld woman lures Bran away; on return centuries have passed and a companion crumbles to ash: classic time dilation. |
| Celtic | [The Science of Fairy Tales](https://sacred-texts.com/neu/celt/sft/index.htm) | Edwin Sidney Hartland, 1891 | S | TIME HYB ABD DIM | Changelings, 'supernatural lapse of time in Fairyland', robberies from fairies: comparative analysis. |
| Icelandic / Norse | [The Poetic Edda](https://sacred-texts.com/neu/poe/index.htm) | Henry Adams Bellows, 1936 | P | CULT HYB SKY | Voluspo, Nine Worlds; Rigsthula: the god Rig (Heimdall) fathers the social classes and teaches runes. |
| Theosophy | [The Secret Doctrine](https://sacred-texts.com/the/sd/index.htm) | Helena P. Blavatsky, 1888 | F | SKY CULT HYB PLUR STAR | Stanzas of Dzyan; Lords of the Flame / Sons of Wisdom endow humanity with mind; root races: foundational text of modern 'star teacher' lore. |
| Theosophy | [The Book of Dzyan (excerpt)](https://sacred-texts.com/atl/dzyan/dzyan.htm) | Helena P. Blavatsky, 1888 | F | SKY HYB | Purported Lemurian scripture: divine beings descend to form humanity. |
| Theosophy | [A Textbook of Theosophy](https://sacred-texts.com/the/tot/index.htm) | C.W. Leadbeater, 1912 | F | SKY CULT PLUR | Lords of the Flame came from Venus to guide earth's evolution. |
| Theosophy | [Initiation, Human and Solar](https://sacred-texts.com/eso/ihas/index.htm) | Alice A. Bailey, 1922 | F | SKY CULT PLUR CHAN | 'The Founding of the Hierarchy': Sanat Kumara comes 'down to this dense physical planet' ~18 million years ago (CORRECTED 2026-09-26: ch. IV does not name Venus; the Venus origin is Scott-Elliot 1904, Leadbeater 1912, Ballard 1934). |
| Atlantis / Lemuria / Mu | [The Story of Atlantis](https://sacred-texts.com/atl/soa/index.htm) | W. Scott-Elliot, 1896 | F | CULT PLUR | Theosophical prehistory: divine rulers guiding the Atlantean races. |
| Atlantis / Lemuria / Mu | [The Lost Lemuria](https://sacred-texts.com/atl/tll/index.htm) | W. Scott-Elliot, 1904 | F | SKY PLUR CULT | Arrival of the Lords of the Flame from Venus in Lemurian times. |
| Esoteric / Occult | [Comte de Gabalis](https://sacred-texts.com/eso/cdg/index.htm) | Abbe N. de Montfaucon de Villars, 1670 (1913 tr.) | F | DIM HYB VEH | Elemental peoples (sylphs, undines, gnomes, salamanders) seeking unions with humans; aerial ships of the sylphs. |
| Esoteric / Occult | [Unveiled Mysteries](https://sacred-texts.com/eso/um/index.htm) | Godfre Ray King (Guy W. Ballard), 1934 | F | PLUR CHAN SKY | I AM movement: St Germain at Mt Shasta; ch. IX 'Venus Visits the Royal Teton' (Venusian masters). |
| Oahspe | [Oahspe, A Kosmon Bible](https://sacred-texts.com/oah/oah/index.htm) | John Ballou Newbrough, 1882 | F | VEH CHAN HYB SKY | Channeled: etherean fire-ships/airships of angels, angel embassadors, prehistoric hybrid races (I'hins, druks). |
| Swedenborg | [Earths in the Universe](https://sacred-texts.com/swd/eiu/index.htm) | Emanuel Swedenborg, 1758 | F | PLUR CHAN | Conversations with spirits of the inhabitants of Mercury, Venus, Mars, Jupiter, Saturn, the Moon and 'earths in the starry heaven'. |
| UFOs | [From India to the Planet Mars](https://sacred-texts.com/ufo/ipm/index.htm) | Theodore Flournoy, tr. D.B. Vermilye, 1900 | S | CHAN PLUR | Psychologist's case study of medium Helene Smith's 'Martian' language and visions: primary for psychological readings of contact. |
| UFOs | [Other Tongues--Other Flesh](https://sacred-texts.com/ufo/otof/index.htm) | George Hunt Williamson, 1953 | U | PLUR HYB SKY CHAN | Ancient-astronaut and 'Wanderers' doctrine; Maldek; reinterprets scripture as extraterrestrial history. |
| UFOs | [The Secret of the Saucers](https://sacred-texts.com/ufo/sos/index.htm) | Orfeo M. Angelucci, ed. Ray Palmer, 1955 | U | CHAN VEH ABD | Early contactee account of benevolent 'space brothers'. |
| UFOs | [We Met the Space People](https://sacred-texts.com/ufo/wmsp/index.htm) | Helen & Betty Mitchell, 1959 | U | CHAN PLUR | Contactees meet 'Space Brothers' from Venus. |
| UFOs | [In Days To Come](https://sacred-texts.com/ufo/idtc/index.htm) | 'Ashtar' (Ethel P. Hill), 1957? | U | CHAN PLUR | Channeled Ashtar messages. |
| UFOs | [Heaven's Gate](https://sacred-texts.com/ufo/hg/index.htm) | Heaven's Gate group, 1990s | U | CHAN VEH SKY | NRM writings: 'Evolutionary Level Above Human', spacecraft as heaven: key modern case study. |
| UFOs | [I Remember Lemuria](https://sacred-texts.com/ufo/irl/index.htm) | Richard S. Shaver, 1948 | U | DIM PLUR HYB | Titans/Atlans from space and degenerate 'deros' in caverns: bridge from Lemuria lore to the UFO craze. |

## 3. Index by category

### African  (`afr`)

Index: https://sacred-texts.com/afr/index.htm  
Status: **relevant**. User's starting point; covered book-by-book (all 29 entries). Strongest: Werner's Bantu 'Heaven People', the Ife descent myth, Kebra Nagast (flying wagon + rebel angels). No Dogon/Griaule ethnography hosted (only a 1995 Usenet post in the UFO BBS files).

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Myths and Legends of the Bantu](https://sacred-texts.com/afr/mlb/index.htm) | Alice Werner | 1933 | S | SKY ABD HYB CULT | Chapters 'The Heaven Country and the Heaven People', 'Mortals Who Have Ascended to Heaven', 'Legends of the High Gods', half-men: best African source for sky-people and sky-journeys. |
| high | [Myths of Ife](https://sacred-texts.com/afr/ife/index.htm) | John Wyndham | 1921 | P | SKY CULT WAR | Yoruba cosmogony in verse: 'The Descent' of the gods from the sky to found Ife; 'The War of the Gods'. |
| high | [The Kebra Nagast](https://sacred-texts.com/afr/kn/index.htm) | tr. E.A. Wallis Budge | 1922 | P | VEH FORB HYB WAR | Ethiopian epic: Solomon's son's wagon flies 'a cubit above the earth' carrying the Ark (ch. 52-53), chariot chapters 113-117 (CORRECTED 2026-09-26: here 'chariot' is a royal palladium; no flight is described), and ch. 100 'Concerning the Angels who rebelled' (Watchers, daughters of Cain, giants). |
| medium | [Drums and Shadows](https://sacred-texts.com/afr/das/index.htm) | Georgia Writers' Project (WPA) | 1940 | E | ABD | Gullah/Geechee testimonies incl. the 'flying Africans' who flew back to Africa; conjure and spirits. |
| medium | [Notes on the Folklore of the Fjort](https://sacred-texts.com/afr/fjort/index.htm) | R.E. Dennett | 1898 | E | SKY ABD | Kongo tales: sky-god Nzambi's daughter won by the spider, 'The Bird-Messengers', 'Nzambi Mpungu's Ambassador', 'Ngomba's Balloon'. |
| medium | [Specimens of Bushman Folklore](https://sacred-texts.com/afr/sbf/index.htm) | W.H.I. Bleek & L.C. Lloyd | 1911 | E | STAR SKY | /Xam star lore: girl of the Early Race who made the stars, star !Gaunu naming stars, 'Sirius and Canopus', prayers to stars; useful Sirius comparandum. |
| medium | [The Religious System of the Amazulu](https://sacred-texts.com/afr/rsa/index.htm) | Henry Callaway | 1870 | E | SKY CULT | Zulu Unkulunkulu, 'Lord of Heaven', heavenly princess Inkosazana and 'heaven-doctors' who deal with sky powers. |
| medium | [The Yoruba Speaking Peoples](https://sacred-texts.com/afr/yor/index.htm) | A.B. Ellis | 1894 | E | SKY CULT | Chief gods: Obatala/Odudua descend from the sky to create land and humans; Orisha pantheon. |
| medium | [Yoruba Legends](https://sacred-texts.com/afr/yl/index.htm) | M.I. Ogumefu | 1929 | E | SKY CULT | 'The Kingdom of the Yorubas': Oranyan spreads iron, cloth, soil and a cock on the primordial water (CORRECTED 2026-09-26: no sky descent in this text). |
| low | [At the Back of the Black Man's Mind](https://sacred-texts.com/afr/mind/index.htm) | R.E. Dennett | 1906 | E | SKY | Bavili cosmology/philosophy and Nzambi; structural, few visitor narratives. |
| low | [Fetichism in West Africa](https://sacred-texts.com/afr/fiwa/index.htm) | Robert Hamill Nassau | 1904 | E | DIM | Missionary typology of 'spiritual beings, their classes and functions' (taxonomy of non-human agents). |
| low | [Folk Stories from Southern Nigeria](https://sacred-texts.com/afr/fssn/index.htm) | Elphinstone Dayrell | 1910 | E | SKY | Efik/Ibibio tales incl. 'Why the Sun and the Moon Live in the Sky'; lightning and thunder as beings. |
| low | [Hausa Folklore](https://sacred-texts.com/afr/hausa/index.htm) | Maalam Shaihu, tr. R.S. Rattray | 1913 | E | - | Hausa origin history and tales (giant and thunder); marginal. |
| low | [Jamaica Anansi Stories](https://sacred-texts.com/afr/jas/index.htm) | Martha Warren Beckwith | 1924 | E | - | Trickster tales ('House in the Air'); Anansi's sky-god background only implicit. |
| low | [Psychic Phenomena of Jamaica](https://sacred-texts.com/afr/ppj/index.htm) | Joseph J. Williams | 1934 | S | DIM | Duppies and spirit phenomena; tangential entity-encounter material. |
| low | [Religion and Myth](https://sacred-texts.com/afr/ram/index.htm) | James Macdonald | 1883 | S | - | Early comparative survey (supernatural, evolution of deity); background only. |
| low | [South African Folk-Tales](https://sacred-texts.com/afr/saft/index.htm) | James A. Honey | 1910 | E | SKY | Mostly animal fables; the Moon's lost message (origin of death) is the only sky-being element. |
| low | [The Holy Piby](https://sacred-texts.com/afr/piby/index.htm) | Robert Athlyi Rogers | 1924-28 | U | - | Proto-Rastafarian scripture; heavenly visions/angels in a political-religious frame; no visitor motifs. |
| low | [The Royal Parchment Scroll of Black Supremacy](https://sacred-texts.com/afr/rps/index.htm) | Fitz Balintine Pettersburg | 1926? | U | - | Proto-Rastafarian; esoteric claims ('The Man Before Adam Was', 'Owner of the Zodiac') but no NHI. |
| low | [Voodoo and Obeahs](https://sacred-texts.com/afr/vao/index.htm) | Joseph J. Williams | 1932 | S | DIM | Serpent cult at Whydah, Haitian Vodun, Obeah; possession by lwa as non-human agents (tangential). |
| low | [Wonderful Ethiopians of the Ancient Cushite Empire](https://sacred-texts.com/afr/we/index.htm) | Drusilla Dunjee Houston | 1927 | F | - | Afrocentric diffusionist prehistory (lost-civilization style); fringe secondary, no NHI. |
| none | [Kaffir (Xhosa) Folk-Lore](https://sacred-texts.com/afr/xft/index.htm) | George McCall Theal | 1886 | E | - | Ogres, magical birds, cannibals; no sky-being or visitor motifs. |
| none | [Last of the Voudoos](https://sacred-texts.com/afr/hearn/lastvdu.htm) | Lafcadio Hearn | 1885 | E | - | Journalistic sketch of a New Orleans Voodoo figure; not relevant. |
| none | [New Orleans Superstitions](https://sacred-texts.com/afr/hearn/nos.htm) | Lafcadio Hearn | 1886 | E | - | Folk superstitions; not relevant. |
| none | [Stolen Legacy](https://sacred-texts.com/afr/stle/index.htm) | George G.M. James | 1954 | F | - | Egyptian Mystery System thesis; not NHI. |
| none | [The Negro](https://sacred-texts.com/afr/dbn/index.htm) | W.E.B. Du Bois | 1915 | S | - | History; not relevant. |
| none | [The Promised Key](https://sacred-texts.com/afr/tpk/index.htm) | G.G. Maragh (Leonard Howell) | 1935? | U | - | Rastafarian founding tract; no NHI motifs. |
| none | [The Wisdom of Rastafari](https://sacred-texts.com/afr/rasta/wisdom.htm) | Haile Selassie (quotations) | n.d. | U | - | Quotation anthology; not relevant. |
| none | [Woman's Mysteries of a Primitive People](https://sacred-texts.com/afr/wmp/index.htm) | D. Amaury Talbot | 1915 | E | - | Ibibio bush-souls, jujus, secret societies; no visitor motifs. |

### Ancient Near East  (`ane`)

Index: https://sacred-texts.com/ane/index.htm  
Status: **relevant**. Core for Anunnaki/Apkallu/Oannes. The Oannes account itself is in Cory's Ancient Fragments (Classics section).

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Adapa and the Food of Life](https://sacred-texts.com/ane/adapa.htm) | R.W. Rogers | 1912 | P | ABD CULT | Adapa, first of the Apkallu sages of Eridu, summoned up to Anu's heaven and offered immortality. |
| high | [Myths and Legends of Babylonia and Assyria](https://sacred-texts.com/ane/mba/index.htm) | Donald A. Mackenzie | 1915 | S | CULT ABD SKY DIM | Ea/Oannes as 'God of the Deep' who taught the arts, Etana's eagle-flight to heaven, Adapa, 'Demons, Fairies, and Ghosts', astrology. |
| high | [Sumerian Mythology](https://sacred-texts.com/ane/sum/index.htm) | Samuel Noah Kramer | 1944/1961 | S | CULT SKY FORB | Scholarly source for the Anunnaki, Enki's 'me' (arts of civilization) transferred to Inanna, creation of humans to serve the gods, Kur. |
| high | [The Seven Tablets of Creation (Enuma Elish)](https://sacred-texts.com/ane/stc/index.htm) | L.W. King | 1902 | P | SKY WAR CULT | Marduk assigns the Anunnaki of heaven and earth; humans created from Kingu's blood to relieve the gods' labour. |
| medium | [Legends of Babylonia and Egypt in Relation to Hebrew Tradition](https://sacred-texts.com/ane/beheb.htm) | Leonard W. King | 1916 | S | CULT HYB | Compares antediluvian kings/sages with Genesis; useful for Apkallu-Watcher links. |
| medium | [Records of the Past](https://sacred-texts.com/ane/rp/index.htm) | ed. A.H. Sayce | 1888 | P | SKY | Translations of Near Eastern myths/historical texts; background. |
| medium | [The Babylonian Legends of Creation](https://sacred-texts.com/ane/blc/index.htm) | E.A. Wallis Budge | 1921 | S | SKY CULT | Creation texts incl. Berossus summary. |
| medium | [The Chaldean Account of Genesis](https://sacred-texts.com/ane/caog/index.htm) | George Smith | 1876 | S | SKY | Early translations (creation, Ishtar's descent, deluge); historic reception text. |
| medium | [The Enuma Elish (single-page text)](https://sacred-texts.com/ane/enuma.htm) | L.W. King | 1902 | P | SKY WAR | Same text, single-page edition. |
| medium | [The Epic of Gilgamish](https://sacred-texts.com/ane/eog/index.htm) | R. Campbell Thompson | 1928 | P | HYB ABD | Two-thirds-divine king, Utnapishtim's divine rescue, Ishtar's advances: semi-divine hybrid kingship. |
| low | [Descent of the Goddess Ishtar into the Lower World](https://sacred-texts.com/ane/ishtar.htm) | M. Jastrow | 1915 | P | ABD | Otherworld journey of a goddess; comparandum. |
| low | [The Chaldean Account of the Deluge](https://sacred-texts.com/ane/chad/index.htm) | George Smith | 1873 | S | - | Announcement of the Babylonian flood tablet. |
| low | [The Religion of Babylonia and Assyria](https://sacred-texts.com/ane/rbaa.htm) | Theophilus G. Pinches | 1906 | S | - | Survey of gods incl. Ea; background. |
| low | [The Seven Evil Spirits](https://sacred-texts.com/ane/seven.htm) | R.C. Thompson | 1903 | P | DIM | Demonic beings; tangential. |

### Egyptian  (`egy`)

Index: https://sacred-texts.com/egy/index.htm  
Status: **relevant**. Stellar afterlife (Orion/imperishable stars), Ra's earthly reign and withdrawal to the sky; Hermetic civilizing myths.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [Egyptian Myth and Legend](https://sacred-texts.com/egy/eml/index.htm) | Donald A. Mackenzie | 1907 | S | CULT | Survey incl. Osiris as civilizing king, Thoth as teacher of writing. |
| medium | [Legends of the Gods: The Egyptian Texts](https://sacred-texts.com/egy/leg/index.htm) | E.A. Wallis Budge | 1912 | P | SKY CULT | Ra's reign on earth, 'Destruction of Mankind', Ra's withdrawal into the sky on Nut's back. |
| medium | [The Egyptian Book of the Dead](https://sacred-texts.com/egy/ebod/index.htm) | E.A. Wallis Budge | 1895 | P | ABD VEH | Otherworld journey in the solar barque; stellar/solar afterlife. |
| medium | [The Pyramid Texts](https://sacred-texts.com/egy/pyt/index.htm) | Samuel A.B. Mercer | 1952 | P | STAR ABD VEH | King ascends to join the imperishable stars and Orion (Sah); sky-ferry and ladder to heaven. |
| low | [Development of Religion and Thought in Ancient Egypt](https://sacred-texts.com/egy/rtae/index.htm) | James Henry Breasted | 1912 | S | STAR | Scholarly discussion of stellar vs solar afterlife in the Pyramid Texts. |
| low | [The Egyptian Heaven and Hell](https://sacred-texts.com/egy/ehh.htm) | E.A. Wallis Budge | 1905 | P | ABD | Amduat/Book of Gates: night-journey through other realms. |
| low | [The Wisdom of the Egyptians](https://sacred-texts.com/egy/woe/index.htm) | Brian Brown | 1923 | F | CULT | Popular; Hermes Trismegistus and the Book of Thoth (knowledge from a god). |

### Bible  (`bib`)

Index: https://sacred-texts.com/bib/index.htm  
Status: **relevant**. Genesis 6 (sons of God/Nephilim), Ezekiel 1 (wheel vision), 1 Enoch, Jubilees and Forgotten Books of Eden (2 Enoch) are hosted under bib/.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [King James Bible: Ezekiel 1](https://sacred-texts.com/bib/kjv/eze001.htm) | KJV | 1611 | P | VEH SKY | Merkabah vision of living creatures and 'wheels within wheels' - the most-cited celestial-vehicle passage. |
| high | [King James Bible: Genesis 6](https://sacred-texts.com/bib/kjv/gen006.htm) | KJV | 1611 | P | HYB SKY | 'Sons of God' take the daughters of men; Nephilim/giants - the canonical seed text. |
| high | [The Book of Enoch](https://sacred-texts.com/bib/boe/index.htm) | tr. R.H. Charles | 1917 | P | SKY FORB HYB ABD WAR STAR | Watchers descend on Mt Hermon, take human wives, beget the Nephilim, teach metallurgy, cosmetics, sorcery and astrology (Azazel, Shemihaza); Enoch's heavenly journeys and astronomical book. |
| high | [The Book of Enoch the Prophet](https://sacred-texts.com/bib/bep/index.htm) | tr. Richard Laurence | 1883 | P | SKY FORB HYB ABD | Earlier translation from the Ethiopic (1 Enoch is canonical in the Ethiopian Orthodox church - African link). |
| high | [The Book of Jubilees](https://sacred-texts.com/bib/jub/index.htm) | tr. R.H. Charles | 1917 | P | FORB HYB CULT | Watchers first sent down to instruct humanity, then fall; giants; Kainan finds the Watchers' astrological inscriptions. |
| high | [The Forgotten Books of Eden (incl. 2 Enoch)](https://sacred-texts.com/bib/fbe/index.htm) | ed. Rutherford H. Platt | 1926 | P | ABD SKY FORB | 2 Enoch: Enoch carried through the heavens by two huge shining men; Grigori (Watchers); Adam and Eve books. |
| medium | [The Biblical Antiquities of Philo](https://sacred-texts.com/bib/bap/index.htm) | tr. M.R. James | 1917 | P | HYB | Pseudo-Philo retelling of Genesis incl. angels and giants. |
| low | [Apocrypha: 2 Esdras](https://sacred-texts.com/bib/apo/es2.htm) | KJV Apocrypha | 1611 | P | ABD | Angelic revelations (Uriel), heavenly visions. |
| low | [The Lost Books of the Bible](https://sacred-texts.com/bib/lbob/index.htm) | ed. Rutherford H. Platt | 1926 | P | - | NT apocrypha; little relevant material. |

### Judaism  (`jud`)

Index: https://sacred-texts.com/jud/index.htm  
Status: **relevant**. Midrashic Watchers (Shemhazai/Azazel), Enoch-Metatron ascent, fallen angels in the Zohar, Josephus on angels begetting giants.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Legends of the Jews](https://sacred-texts.com/jud/loj/index.htm) | Louis Ginzberg | 1909 | S | FORB HYB ABD SKY WAR | Midrash compendium: Shemhazai and Azazel, Naamah, giants, Enoch translated to heaven as Metatron, angels teaching arts. |
| medium | [The Works of Flavius Josephus](https://sacred-texts.com/jud/josephus/index.htm) | tr. William Whiston | 1737 | P | HYB CULT | Antiquities I.3: angels 'accompanied with women' and begat giants; Sethites' astronomical pillars. |
| medium | [The Zohar: Bereshith to Lekh Lekha](https://sacred-texts.com/jud/zdm/index.htm) | Nurho de Manhar | 1900-14 | P | FORB HYB | Kabbalistic treatment of fallen angels Aza and Azael and the Nefilim. |
| low | [Hebraic Literature](https://sacred-texts.com/jud/hl/index.htm) | ed. Maurice Harris | 1901 | P | - | Talmud/Midrash extracts incl. angel lore. |
| low | [Jewish Fairy Tales and Legends](https://sacred-texts.com/jud/jftl/index.htm) | Gertrude Landa | 1919 | P | DIM | Retellings incl. Solomon and Ashmedai the demon king. |
| low | [Jewish Magic and Superstition](https://sacred-texts.com/jud/jms/index.htm) | Joshua Trachtenberg | 1939 | S | DIM | Shedim/demons and angels as non-human intelligences in folk religion. |

### Christianity / Apocrypha  (`chr`)

Index: https://sacred-texts.com/chr/index.htm  
Status: **relevant**. Apocrypha index (chr/apo) plus Syriac works re-reading Genesis 6.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [The Book of Jasher](https://sacred-texts.com/chr/apo/jasher/index.htm) | (1840 English ed.) | 1840 | P | ABD VEH HYB | Midrashic chronicle: corruption before the flood, giants, Enoch's reign and ascent in a fiery chariot drawn by horses. |
| medium | [The Book of the Bee](https://sacred-texts.com/chr/bb/index.htm) | tr. E.A. Wallis Budge | 1886 | P | HYB WAR | Nestorian compendium with angelology and Sethite/Watcher tradition. |
| medium | [The Book of the Cave of Treasures](https://sacred-texts.com/chr/bct/index.htm) | tr. E.A. Wallis Budge | 1927 | P | HYB | Syriac: 'sons of God' re-read as Sethites descending the holy mountain to Cainite women; giants. |
| low | [Apocrypha Arabica](https://sacred-texts.com/chr/aa/index.htm) | Margaret Dunlop Gibson | 1901 | P | - | Arabic apocrypha; some angelology. |
| low | [Paradise Lost, Paradise Regained](https://sacred-texts.com/chr/milton/index.htm) | John Milton | 1667 | L | WAR PLUR | War in Heaven; Raphael visits Adam and muses on life on other worlds (Book VIII). |
| low | [The Aquarian Gospel of Jesus the Christ](https://sacred-texts.com/chr/agjc/index.htm) | Levi H. Dowling | 1908 | F | CHAN | Akashic-record channeled gospel; New Age precursor. |
| low | [The Works of Dionysius the Areopagite](https://sacred-texts.com/chr/dio/index.htm) | tr. John Parker | 1897 | P | DIM | Celestial Hierarchy: canonical Christian taxonomy of non-human intelligences. |

### Gnosticism / Hermetica  (`gno`)

Index: https://sacred-texts.com/gno/index.htm  
Status: **relevant**. Archons/aeons and descending revealers; the Manichaean Book of Giants is the strongest item.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [The Book of Giants (Manichaean)](https://sacred-texts.com/chr/giants/giants.htm) | tr. W.B. Henning | 1943 | P | HYB FORB WAR | Fragments on the Watchers' giant sons (Ohya, Mahaway) and their dreams: Enochic tradition in Central Asia. |
| medium | [Fragments of a Faith Forgotten](https://sacred-texts.com/gno/fff/index.htm) | G.R.S. Mead | 1900 | S | SKY DIM | Sourcebook on Gnostic archons, aeons and descending saviours. |
| medium | [Pistis Sophia](https://sacred-texts.com/chr/ps/index.htm) | tr. G.R.S. Mead | 1921 | P | FORB SKY DIM | Archons and aeons; rebel rulers whose mysteries of magic/astrology reached humanity; descending revealer. |
| medium | [The Virgin of the World (Kore Kosmou)](https://sacred-texts.com/eso/vow/index.htm) | tr. Anna Kingsford & Edward Maitland | 1885 | P | SKY CULT | God sends Isis and Osiris down to civilize humanity; Hermes' hidden books. |
| medium | [Thrice-Greatest Hermes (3 vols)](https://sacred-texts.com/gno/th1/index.htm) | G.R.S. Mead | 1906 | P | CULT SKY | Hermetica incl. Poimandres (divine Mind instructs a man) and Kore Kosmou. |
| low | [The Gnostics and Their Remains](https://sacred-texts.com/gno/gar/index.htm) | Charles William King | 1887 | S | DIM | Gnostic gems/archons; background. |

### Islam  (`isl`)

Index: https://sacred-texts.com/isl/index.htm  
Status: **relevant**. Jinn (a third order of intelligent beings), Harut & Marut teaching sorcery (Q 2:102), Idris/Enoch, Mi'raj ascent.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [The Bible, the Koran, and the Talmud (Biblical Legends of the Mussulmans)](https://sacred-texts.com/isl/bkt/index.htm) | Gustav Weil | 1863 | S | FORB DIM ABD WAR | Idris/Enoch, jinn before Adam, angels' descent. (CORRECTED 2026-09-26: the fetched chapters (Adam, Idris, Solomon) do NOT contain a Harut & Marut narrative; that tale is Qur'an 2:102 plus tafsir.) |
| high | [The Holy Quran (Yusuf Ali)](https://sacred-texts.com/isl/yaq/index.htm) | Abdullah Yusuf Ali | 1934 | P | DIM FORB ABD | Jinn as a separate intelligent species (Surah 72 al-Jinn; 55; 46:29), Harut & Marut teaching sorcery at Babylon (2:102), Idris raised high (19:56-57). |
| medium | [Folk-lore of the Holy Land](https://sacred-texts.com/asia/flhl/index.htm) | J.E. Hanauer | 1907 | E | DIM | Palestinian Muslim/Christian/Jewish lore of jinn, afarit and angels. |
| medium | [Hadith of Bukhari](https://sacred-texts.com/isl/bukhari/index.htm) | tr. M. Muhsin Khan | - | P | ABD VEH DIM | Mi'raj/Night Journey on Buraq through the heavens; jinn eavesdropping at heaven's gates. |
| medium | [Hypertext Qur'an (all translations)](https://sacred-texts.com/isl/htq/index.htm) | various | - | P | DIM FORB | Parallel Qur'an versions for the passages above. |
| medium | [The Arabian Nights (Burton)](https://sacred-texts.com/neu/burt1k1/index.htm) | Richard F. Burton | 1885 | L | DIM VEH ABD | Jinn/marids, the Ebony Horse flying machine, journeys to other realms. |

### Zoroastrianism  (`zor`)

Index: https://sacred-texts.com/zor/index.htm  
Status: **relevant**. Tishtrya/Sirius star-yazata, fravashis, Yima's vara; moderate relevance.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [Pahlavi Texts I: Bundahishn etc. (SBE 5)](https://sacred-texts.com/zor/sbe05/index.htm) | E.W. West | 1880 | P | STAR SKY WAR | Cosmogony, stars as warriors, primeval man Gayomard, fravashis choosing incarnation. |
| medium | [The Zend Avesta I: Vendidad (SBE 4)](https://sacred-texts.com/zor/sbe04/index.htm) | James Darmesteter | 1880 | P | CULT | Yima's vara: Ahura Mazda instructs Yima to build an enclosure sheltering the seeds of life from a catastrophic winter. |
| medium | [The Zend Avesta II: Sirozahs, Yasts (SBE 23)](https://sacred-texts.com/zor/sbe23/index.htm) | James Darmesteter | 1882 | P | STAR SKY WAR | Tir Yasht: Tishtrya (Sirius) star-being battles the drought-demon Apaosha; Fravashis descend. |
| low | [Pahlavi Texts V: Marvels of Zoroastrianism (SBE 47)](https://sacred-texts.com/zor/sbe47/index.htm) | E.W. West | 1897 | P | HYB SKY | Zoroaster's supernatural conception (glory descends from the endless light). |

### Hinduism  (`hin`)

Index: https://sacred-texts.com/hin/index.htm  
Status: **relevant**. Vimanas (Pushpaka, Saubha), deva-asura wars, Matsya-Manu flood teacher, lokas. No Samarangana Sutradhara or Vaimanika Shastra hosted.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Ramayan of Valmiki](https://sacred-texts.com/hin/rama/index.htm) | Ralph T.H. Griffith | 1870-74 | P | VEH DIM | Pushpaka vimana (Ravana's aerial car) carries Rama home; rakshasas and vanaras as non-human peoples. |
| high | [The Mahabharata (Ganguli)](https://sacred-texts.com/hin/maha/index.htm) | tr. K.M. Ganguli | 1883-96 | P | VEH ABD WAR HYB | Vimanas of the gods; Salva's flying city Saubha (Vana Parva); Arjuna carried to Indra's heaven in Matali's chariot; celestial weapons. |
| medium | [Hindu Mythology, Vedic and Puranic](https://sacred-texts.com/hin/hmvp/index.htm) | W.J. Wilkins | 1900 | S | DIM HYB | Survey incl. divine rishis, demigods, 'Superhuman, Though Not Divine Beings' (gandharvas, apsaras, vidyadharas). |
| medium | [Indian Myth and Legend](https://sacred-texts.com/hin/iml/index.htm) | Donald A. Mackenzie | 1913 | S | DIM ABD | Survey incl. 'Demons and Giants and Fairies', ascent to heaven. |
| medium | [Satapatha Brahmana (SBE 12, 26, 41, 43, 44)](https://sacred-texts.com/hin/sbr/index.htm) | Julius Eggeling | 1882-1900 | P | CULT | Manu and the fish (Matsya) that warns of the flood and instructs him: an Oannes-like teacher. |
| medium | [The Rig-Veda](https://sacred-texts.com/hin/rigveda/index.htm) | Ralph Griffith | 1896 | P | VEH SKY CULT WAR | Ashvins' flying chariot, Ribhus (mortal artisans made divine), Maruts, Indra's wars. |
| medium | [The Vishnu Purana](https://sacred-texts.com/hin/vp/index.htm) | H.H. Wilson | 1840 | P | SKY DIM | Lokas/planes, descending avatars, Kalki, cosmic time cycles. |
| low | [The Ramayana and Mahabharata (condensed)](https://sacred-texts.com/hin/dutt/index.htm) | R.C. Dutt | 1899 | P | VEH | Condensed verse epics (vimana episodes). |
| low | [The S'rimad Devi Bhagawatam](https://sacred-texts.com/hin/db/index.htm) | Swami Vijnanananda | 1921 | P | VEH WAR | Puranic lokas, celestial cars, deva wars. |

### Buddhism  (`bud`)

Index: https://sacred-texts.com/bud/index.htm  
Status: **relevant**. Abhassara 'radiant' beings, devas from many world-systems, Buddha-field multiverse.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [Dialogues of the Buddha (Digha Nikaya I)](https://sacred-texts.com/bud/dob/index.htm) | T.W. Rhys Davids | 1899 | P | SKY STAR PLUR | Brahmajala Sutta: radiant Abhassara beings 'fall' into this world at the start of an aeon; Kevaddha: a monk travels through the deva realms. |
| medium | [Saddharma-pundarika (Lotus Sutra) SBE 21](https://sacred-texts.com/bud/lotus/index.htm) | H. Kern | 1884 | P | PLUR SKY | Bodhisattvas arriving from other world-systems; myriad buddha-fields (a Buddhist multiverse). |
| low | [Buddhism in Tibet](https://sacred-texts.com/bud/bit/index.htm) | Emil Schlagintweit | 1863 | S | DIM | Tibetan cosmology, deities and demons. |
| low | [The Fo-Sho-Hing-Tsan-King (Life of Buddha) SBE 19](https://sacred-texts.com/bud/sbe19/index.htm) | Samuel Beal | 1883 | P | SKY HYB | Bodhisattva descends from Tushita heaven into Maya's womb; devas attend. |
| low | [The Jataka (6 vols)](https://sacred-texts.com/bud/j1/index.htm) | ed. E.B. Cowell | 1895-1907 | P | DIM VEH | Devas, nagas and yakkhas interacting with humans; Sakka's heavenly chariot. |

### Jainism  (`jai`)

Index: https://sacred-texts.com/jai/index.htm  
Status: **relevant**. Kalpa Sutra: Mahavira descends from a celestial vimana; embryo transferred between wombs by the god Harinegamesi.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [Jaina Sutras I (Akaranga & Kalpa Sutra) SBE 22](https://sacred-texts.com/jai/sbe22/index.htm) | Hermann Jacobi | 1884 | P | SKY HYB VEH | Mahavira descends from the Pushpottara celestial vimana; Sakra has the god Harinegamesi transfer the embryo from Devananda to Trisala. |
| low | [Jaina Sutras II SBE 45](https://sacred-texts.com/jai/sbe45/index.htm) | Hermann Jacobi | 1895 | P | DIM VEH | Jain cosmology of vaimanika gods (dwelling in vimanas) and other beings. |

### Sikhism  (`skh`)

Index: https://sacred-texts.com/skh/index.htm  
Status: **no clear relevant material**. NO clear relevant material (only 3 items).

### Baha'i  (`bhi`)

Index: https://sacred-texts.com/bhi/index.htm  
Status: **no clear relevant material**. NO clear relevant material (theological/ethical texts).

### Confucianism / Chinese religion  (`cfu`)

Index: https://sacred-texts.com/cfu/index.htm  
Status: **relevant**. Mostly ethical/ritual canon: little relevant material; Werner's Myths and Legends of China is the exception.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [Myths and Legends of China](https://sacred-texts.com/cfu/mlc/index.htm) | Edward T.C. Werner | 1922 | S | SKY ABD | Celestial bureaucracy, immortals, Chang'e on the moon, Yellow Emperor ascending on a dragon. |

### Taoism  (`tao`)

Index: https://sacred-texts.com/tao/index.htm  
Status: **marginal**. Low: Lieh-tzu's celestial journeys are marginal.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| low | [Taoist Teachings from the Book of Lieh-Tzu](https://sacred-texts.com/tao/tt/index.htm) | Lionel Giles | 1912 | P | ABD | King Mu carried by a magician to celestial palaces; riding the wind. |

### Shinto / Japan / Ainu  (`shi`)

Index: https://sacred-texts.com/shi/index.htm  
Status: **relevant**. High: Kojiki/Nihongi descent of the heavenly grandson from Takamagahara; Heavenly Rock-Boat; Ainu culture hero from heaven.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Nihongi (Part 1 of 4)](https://sacred-texts.com/shi/nihon0.htm) | W.G. Aston | 1896 | P | SKY VEH HYB | Parallel accounts; Nigihayahi descends in the 'Heavenly Rock-Boat' (Ama-no-iwafune). |
| high | [The Kojiki](https://sacred-texts.com/shi/kj/index.htm) | Basil Hall Chamberlain | 1882 (1919 ed.) | P | SKY HYB CULT | Descent of the heavenly grandson Ninigi from Takamagahara via the Floating Bridge of Heaven; heavenly deities found the imperial line. |
| medium | [Aino Folk-Tales](https://sacred-texts.com/shi/aft/index.htm) | Basil Hall Chamberlain | 1888 | E | CULT SKY | Ainu tales; culture hero (Okikurumi/Aeoina) who came from heaven to teach the Ainu. |
| medium | [Kogoshui: Gleanings from Ancient Stories](https://sacred-texts.com/shi/kgsh/index.htm) | Genchi Kato & H. Hoshino | 1926 | P | SKY | Imbe-clan version of the heavenly descent. |

### Asia (Siberia, Caucasus, SE Asia, Near East folk)  (`asia`)

Index: https://sacred-texts.com/asia/index.htm  
Status: **relevant**. Siberian sky-world journeys; Buriat Tengeri sending culture heroes; Yezidi angel lore.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [A Journey in Southern Siberia](https://sacred-texts.com/asia/jss/index.htm) | Jeremiah Curtin | 1909 | E | SKY CULT | Buriat myths: Tengeri sky-gods send a son to earth; first shaman sent by the sky. |
| medium | [Chukchee Mythology](https://sacred-texts.com/asia/cm/index.htm) | Waldemar Bogoras | 1910 | E | STAR ABD | Journeys to the upper world, star-people and sky beings. |
| low | [Devil Worship: The Sacred Books and Traditions of the Yezidiz](https://sacred-texts.com/asia/sby/index.htm) | Isya Joseph | 1919 | P | SKY DIM | Melek Taus and the seven angels who govern the world. |
| low | [Koryak Texts](https://sacred-texts.com/asia/kort/index.htm) | Waldemar Bogoras | 1917 | E | ABD | Big-Raven cycle; sky visits. |
| low | [Myths and Legends of the Andamans](https://sacred-texts.com/asia/tai/index.htm) | A.R. Radcliffe-Brown | 1922 | E | SKY | Ancestral beings, sky-world. |
| low | [Philippine Folk Tales](https://sacred-texts.com/asia/pft/index.htm) | Mabel Cook Cole | 1916 | E | STAR HYB | Sky-people and star-maiden type tales. |

### Shamanism  (`sha`)

Index: https://sacred-texts.com/sha/index.htm  
Status: **relevant**. Shamanic ascent to upper worlds, spirit spouses (cross-listed items).

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [Shamanism in Siberia](https://sacred-texts.com/sha/sis/index.htm) | M.A. Czaplicka | 1914 | S | ABD HYB | Shaman's ascent to the upper world, sky-spirit spouses: comparative baseline for journey motifs. |

### Native American  (`nam`)

Index: https://sacred-texts.com/nam/index.htm  
Status: **relevant**. Very rich: Star Husband cycle, Sky Woman, Pleiades, Morning Star/Scarface, Viracocha/Quetzalcoatl culture heroes, Chinigchinich, Warao sky-origin.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Blackfoot Lodge Tales](https://sacred-texts.com/nam/pla/blt/index.htm) | George Bird Grinnell | 1892 | E | STAR ABD CULT HYB | 'Scarface' (journeys to Sun and Morning Star, brings the Sun Dance), 'The Lost Woman', 'The Theft from the Sun'. |
| high | [Chinigchinich (Boscana)](https://sacred-texts.com/nam/ca/bosc/index.htm) | Fr. Geronimo Boscana, tr. A. Robinson | 1846 | E | CULT STAR SKY | Acagchemem: Chinigchinich appeared, taught laws and ceremonies, then went up to the stars. |
| high | [Iroquoian Cosmology](https://sacred-texts.com/nam/iro/irc/index.htm) | J.N.B. Hewitt | 1903 | E | SKY STAR | Onondaga, Seneca and Mohawk versions of Sky Woman falling from the Sky World to found earth and humanity. |
| high | [Myths of the Cherokee](https://sacred-texts.com/nam/cher/motc/index.htm) | James Mooney | 1900 | E | STAR DIM ABD | 'What the Stars Are Like', 'Origin of the Pleiades and the Pine', 'The Milky Way', Nunnehi immortals, 'The Journey to the Sunrise'. |
| high | [Tales of the North American Indians](https://sacred-texts.com/nam/tnai/index.htm) | Stith Thompson | 1929 | S | STAR ABD HYB CULT | Comparative corpus incl. the 'Star Husband' tale (women taken to the sky as star-wives), 'Journeys to the Other World', culture heroes. |
| high | [The Myths of Mexico and Peru](https://sacred-texts.com/nam/mmp/index.htm) | Lewis Spence | 1913 | S | CULT SKY | Quetzalcoatl and Viracocha as departing civilizing culture heroes; diffusionist-era survey. |
| high | [Traditions of the Hopi](https://sacred-texts.com/nam/hopi/toth/index.htm) | H.R. Voth | 1905 | E | STAR CULT DIM | Emergence myth, katcinas who became stars, Spider Woman; supernatural teachers of the clans. |
| high | [Viracocha and the Coming of the Incas](https://sacred-texts.com/nam/inca/inca01.htm) | (retelling) | - | P | CULT SKY STAR | Children of the Sun sent to civilize humanity; Viracocha teacher-god. |
| medium | [Animism and Folk-Lore of the Guiana Indians](https://sacred-texts.com/nam/sa/aflg/index.htm) | Walter E. Roth | 1915 | E | STAR DIM | Sky-people, star lore, spirit taxonomy. |
| medium | [Legends and Myths of the Aboriginal Indians of British Guiana](https://sacred-texts.com/nam/sa/lmbg/index.htm) | William Henry Brett | 1880 | E | SKY STAR | Warao origin: people once lived above the sky and descended to earth through a hole; sky-maiden tales. |
| medium | [Navajo Creation Myth](https://sacred-texts.com/nam/nav/ncm/index.htm) | Hasteen Klah / Mary C. Wheelwright | 1942 | E | CULT STAR | Holy People, lower worlds, placing of the stars. |
| medium | [Origin Myth of Acoma](https://sacred-texts.com/nam/sw/oma/index.htm) | Matthew W. Stirling | 1942 | E | CULT | Iatiku, emergence, katsina who came and taught. |
| medium | [Origin Myths of the Navaho Indians](https://sacred-texts.com/nam/nav/omni/index.htm) | Aileen O'Bryan | 1956 | E | CULT DIM | Holy People and emergence through lower worlds; teachers of ceremonies. |
| medium | [Pueblo Indian Folk-Stories](https://sacred-texts.com/nam/sw/pifs/index.htm) | Charles F. Lummis | 1910 | E | SKY HYB | 'The Man Who Married the Moon', 'Mother Moon', 'The Ants that Pushed on the Sky'. |
| medium | [Seneca Indian Myths](https://sacred-texts.com/nam/iro/sim/index.htm) | Jeremiah Curtin | 1922 | E | ABD STAR | 'Two Young Men Who Went to The Blue', the Morning Star, visits to the Thunders. |
| medium | [Tales and Traditions of the Eskimo](https://sacred-texts.com/nam/inu/tte/index.htm) | Henry Rink | 1875 | E | ABD SKY | Visits to (and abductions by) the Moon-man; journeys to sky and sea worlds. |
| medium | [The Algonquin Legends of New England](https://sacred-texts.com/nam/ne/al/index.htm) | Charles G. Leland | 1884 | E | CULT DIM | Glooskap culture hero who departs promising return; fairy-like beings. |
| medium | [The Book of Chilam Balam of Chumayel](https://sacred-texts.com/nam/maya/cbc/index.htm) | Ralph L. Roys | 1933 | P | SKY | Maya katun prophecies, descent of the 13 gods, arrival of strangers. |
| medium | [The Code of Handsome Lake](https://sacred-texts.com/nam/iro/parker/index.htm) | Arthur C. Parker | 1913 | E | ABD CHAN | Seneca prophet visited by four messengers and taken on a sky journey. |
| medium | [The Old North Trail](https://sacred-texts.com/nam/pla/ont/index.htm) | Walter McClintock | 1910 | E | STAR CULT | Blackfoot sun worship, star legends, ceremonies given by sky-beings. |
| medium | [The Popol Vuh (excerpt)](https://sacred-texts.com/nam/pvuheng.htm) | Lewis Spence | 1908 | P | STAR SKY | Gods' repeated attempts to make humans; Hero Twins become sun and moon; 400 boys become the Pleiades. (NOTE 2026-09-26: sacred-texts Popol Vuh pages now return 404; the Goetz-Morley 1950 translation via bibliotecapleyades was used.) |
| medium | [The Sun Dance and Other Ceremonies of the Oglala](https://sacred-texts.com/nam/pla/sdo/index.htm) | J.R. Walker | 1917 | E | CULT STAR | Lakota wakan beings and sky-derived ceremonies. |
| low | [Creation Myths of Primitive America](https://sacred-texts.com/nam/ca/cma/index.htm) | Jeremiah Curtin | 1898 | E | DIM | Wintu/Yana 'First People' who preceded humans and were transformed. |
| low | [Eskimo Folk-tales](https://sacred-texts.com/nam/inu/eft/index.htm) | Knud Rasmussen | 1921 | E | ABD | Inuit sky journeys, spirit beings. |
| low | [The Thunder Bird Tootooch Legends](https://sacred-texts.com/nam/nw/ttb/index.htm) | W.L. Weber | 1936 | E | SKY | Thunderbird as sky being. |
| low | [Tlingit Myths and Texts](https://sacred-texts.com/nam/nw/tmt/index.htm) | John R. Swanton | 1909 | E | SKY ABD | Raven steals the light from the sky chief; sky visits. |
| low | [Tsimshian Texts (New Series)](https://sacred-texts.com/nam/nw/tst/index.htm) | Franz Boas | 1912 | E | STAR ABD | Sky visits, star-husband variants. |
| low | [Zuni Folk Tales](https://sacred-texts.com/nam/zuni/zft/index.htm) | Frank Hamilton Cushing | 1901 | E | DIM | Kachina and sky beings. |

### Pacific  (`pac`)

Index: https://sacred-texts.com/pac/index.htm  
Status: **relevant**. Tane's ascent for the baskets of knowledge, sky fathers, Tagaloa, Maui; Menehune hidden people.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [The Lore of the Whare-Wananga](https://sacred-texts.com/pac/lww/index.htm) | S. Percy Smith | 1913 | E | CULT FORB ABD SKY | Maori whare-wananga teaching: Tane ascends to the uppermost heaven and brings back the three baskets of knowledge; twelve heavens. |
| medium | [Hawaiian Mythology](https://sacred-texts.com/pac/hm/index.htm) | Martha Warren Beckwith | 1940 | S | SKY DIM | 'Coming of the Gods', 'Mythical Lands of the Gods' (hidden floating islands), Papa and Wakea. |
| medium | [Legends of Maui](https://sacred-texts.com/pac/maui/index.htm) | W.D. Westervelt | 1910 | E | CULT | Culture hero who snares the sun and brings fire. |
| medium | [Maori Religion and Mythology](https://sacred-texts.com/pac/mrm/index.htm) | Edward Shortland | 1882 | E | SKY | Maori cosmology and heavens. |
| medium | [Oceanic Mythology](https://sacred-texts.com/pac/om/index.htm) | Roland B. Dixon | 1916 | S | SKY CULT | Comparative Pacific and Australian origins, sky-descent and culture-hero tales. |
| medium | [Polynesian Mythology](https://sacred-texts.com/pac/grey/index.htm) | Sir George Grey | 1854 | E | SKY ABD HYB | Children of Rangi and Papa; Tawhaki's ascent to heaven; sky-wife. |
| medium | [The Kumulipo](https://sacred-texts.com/pac/ku/index.htm) | Martha Warren Beckwith | 1951 | P | HYB | Hawaiian genealogy chant from cosmos to chiefs (divine descent). |
| medium | [The Samoan Story of Creation](https://sacred-texts.com/pac/jpolys/ssc.htm) | John Fraser | 1891 | E | SKY | Tagaloa in the heavens sends his daughter (bird) to make land and people. |
| low | [Hawaiian Folk Tales](https://sacred-texts.com/pac/hft/index.htm) | Thomas G. Thrum | 1907 | E | DIM | Menehune (hidden small people). |
| low | [Te Pito Te Henua, or Easter Island](https://sacred-texts.com/pac/ei/index.htm) | William J. Thomson | 1891 | E | - | Rongorongo, Makemake, Hotu Matua; often cited in fringe literature. |

### Australia  (`aus`)

Index: https://sacred-texts.com/aus/index.htm  
Status: **relevant**. Baiame sky-hero lawgiver, Seven Sisters (Pleiades), Morning Star, Alcheringa ancestors.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Australian Legendary Tales](https://sacred-texts.com/aus/alt/index.htm) | K. Langloh Parker | 1897 | E | STAR CULT | 'Meamei the Seven Sisters' (Pleiades), 'Mullyangah the Morning Star', 'The Borah of Byamee'. |
| high | [The Euahlayi Tribe](https://sacred-texts.com/aus/tet/index.htm) | K. Langloh Parker | 1905 | E | CULT SKY STAR | Byamee (Baiame), the All-Father who lived on earth, gave laws and the Boorah, then went up to the sky; chapter 'Something About Stars and Legends'. |
| medium | [The Native Tribes of Central Australia](https://sacred-texts.com/aus/ntca/index.htm) | Baldwin Spencer & F.J. Gillen | 1899 | E | CULT DIM | Alcheringa ancestors, Iruntarinia spirit individuals, sun/moon myths. |
| low | [Australian Legends](https://sacred-texts.com/aus/peck/index.htm) | C.W. Peck | 1925 | E | STAR | Retold tales incl. sky beings. |
| low | [Native Tribes of the Northern Territory of Australia](https://sacred-texts.com/aus/ntna/index.htm) | Baldwin Spencer | 1914 | E | CULT | Ethnography; ancestral beings. |
| low | [Some Myths and Legends of the Australian Aborigines](https://sacred-texts.com/aus/mla/index.htm) | W. Jenkyn Thomas | 1923 | E | STAR | Retold tales incl. star myths. |

### Classics  (`cla`)

Index: https://sacred-texts.com/cla/index.htm  
Status: **relevant**. Berossus/Oannes (Cory), Prometheus, Atlantis, Lucian's lunar voyage, Sibylline Watchers.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Ancient Fragments (Cory)](https://sacred-texts.com/cla/af/index.htm) | I.P. Cory | 1832 | P | CULT FORB HYB | Berossus (via Polyhistor, Apollodorus, Abydenus): Oannes and the Annedoti, fish-man beings from the Erythraean Sea who taught letters, sciences and city-building; Sanchuniathon's Phoenician theology. |
| medium | [A True Story (Lucian)](https://sacred-texts.com/cla/luc/true/index.htm) | tr. A.M. Harmon | 1913 | L | PLUR ABD WAR | Voyage to the Moon; war between Moon-people and Sun-people: earliest extant space-voyage satire. |
| medium | [Critias (with Timaeus)](https://sacred-texts.com/cla/plato/critias.htm) | Plato, tr. B. Jowett | 360 BCE | P | HYB CULT | Atlantis founded by Poseidon's offspring with a mortal woman; Egyptian priests' deep-time memory. |
| medium | [Hesiod's Theogony](https://sacred-texts.com/cla/hesiod/theogony.htm) | tr. H.G. Evelyn-White | 1914 | P | FORB WAR | Titans vs Olympians; Prometheus steals fire for humanity. |
| medium | [The Sibylline Oracles](https://sacred-texts.com/cla/sib/index.htm) | tr. Milton S. Terry | 1899 | P | FORB HYB | Book I: Watchers (Egregoroi) and giant races. |
| medium | [Works and Days](https://sacred-texts.com/cla/hesiod/works.htm) | tr. H.G. Evelyn-White | 1914 | P | HYB FORB | Five races of men incl. the demigod race; Pandora. |
| low | [Astrology and Religion among the Greeks and Romans](https://sacred-texts.com/astro/argr/index.htm) | Franz Cumont | 1912 | S | STAR | Astral religion: souls descend from and return to the stars. |
| low | [Metamorphoses (Ovid)](https://sacred-texts.com/cla/ovid/meta/index.htm) | Ovid | 8 CE | P | VEH SKY | Phaethon's solar chariot; gods visiting mortals incognito (Baucis and Philemon). |

### Legends & Sagas (general: Slavic, Finnish, Germanic, Persian, Arabian Nights)  (`neu`)

Index: https://sacred-texts.com/neu/index.htm  
Status: **relevant**. Arabian Nights jinn & flying horse; Shahnameh flying throne; Kalevala; mostly low.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [The Shah Namah](https://sacred-texts.com/neu/shahnama.txt) | Ferdowsi, tr. Helen Zimmern | 1883 | P | VEH FORB | Kay Kavus's flying throne lifted by eagles; captured divs teach writing to Tahmuras. |
| low | [The Kalevala](https://sacred-texts.com/neu/kveng/index.htm) | tr. J.M. Crawford | 1888 | P | CULT | Ilmarinen forged the sky-vault and forges the Sampo; Vainamoinen departs promising return. |

### Celtic  (`celt`)

Index: https://sacred-texts.com/neu/celt/index.htm  
Status: **relevant**. Top-tier folklore section: Tuatha De Danann, sidhe, fairy abduction, time dilation, changelings (Kirk, Evans-Wentz, Hartland).

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Gods and Fighting Men](https://sacred-texts.com/neu/celt/gafm/index.htm) | Lady Augusta Gregory | 1904 | P | CULT DIM ABD TIME | Tuatha De Danann arrival, Lugh master of all arts, Manannan's calls to Bran and Connla, Laegaire in the Happy Plain. |
| high | [The Fairy-Faith in Celtic Countries](https://sacred-texts.com/neu/celt/ffcc/index.htm) | W.Y. Evans-Wentz | 1911 | E | DIM ABD TIME HYB | Field testimony from six Celtic lands on fairy encounters, abductions, 'People of the Goddess Dana', the Otherworld: key comparative source for abduction-lore parallels. |
| high | [The Science of Fairy Tales](https://sacred-texts.com/neu/celt/sft/index.htm) | Edwin Sidney Hartland | 1891 | S | TIME HYB ABD DIM | Changelings, 'supernatural lapse of time in Fairyland', robberies from fairies: comparative analysis. |
| high | [The Second Battle of Mag Tuired (Cath Maige Tuired)](https://sacred-texts.com/neu/cmt/cmteng.htm) | tr. Elizabeth A. Gray (CORRECTED: not Stokes 1891) | 1982 | P | CULT WAR HYB SKY | Tuatha De Danann vs Fomorians; Lugh, the Dagda; half-Fomorian king Bres (in Lebor Gabala tradition the Tuatha arrive in dark clouds). |
| high | [The Secret Common-Wealth of Elves, Fauns and Fairies](https://sacred-texts.com/neu/celt/sce/index.htm) | Robert Kirk (1691), comm. Andrew Lang | 1893 | P | DIM ABD HYB | 17th-c. minister's treatise on the 'subterranean inhabitants' of intermediate nature, second sight, abductions. |
| high | [The Voyage of Bran](https://sacred-texts.com/neu/celt/vob/index.htm) | Kuno Meyer | 1895 | P | TIME ABD DIM | An otherworld woman lures Bran away; on return centuries have passed and a companion crumbles to ash: classic time dilation. |
| medium | [British Goblins](https://sacred-texts.com/neu/celt/wfl/index.htm) | Wirt Sikes | 1881 | E | DIM TIME | Welsh Tylwyth Teg lore incl. abductions and lapse of time. |
| medium | [Celtic Folklore: Welsh and Manx](https://sacred-texts.com/neu/cfwm/index.htm) | John Rhys | 1900 | E | DIM TIME HYB | Welsh fairy-bride and abduction tales with lapse of time. |
| medium | [Celtic Myth and Legend](https://sacred-texts.com/neu/celt/cml/index.htm) | Charles Squire | 1905 | S | CULT DIM | Survey of the Tuatha De Danann and British gods. |
| medium | [Cuchulain of Muirthemne](https://sacred-texts.com/neu/celt/cuch/index.htm) | Lady Augusta Gregory | 1902 | P | HYB DIM | Cuchulain fathered by Lugh; sidhe women. |
| medium | [Fairy and Folk Tales of the Irish Peasantry](https://sacred-texts.com/neu/yeats/fip/index.htm) | ed. W.B. Yeats | 1888 | E | HYB DIM | Changelings, trooping fairies. |
| medium | [Heroic Romances of Ireland](https://sacred-texts.com/neu/hroi/index.htm) | A.H. Leahy | 1905-06 | P | ABD DIM HYB | Courtship of Etain (Midir of the Sidhe); otherworld journeys. |
| medium | [Myths and Legends of the Celtic Race](https://sacred-texts.com/neu/celt/mlcr/index.htm) | T.W. Rolleston | 1911 | S | CULT DIM | Survey incl. the invasions cycle. |
| medium | [The Candle of Vision](https://sacred-texts.com/neu/celt/cov/index.htm) | AE (George William Russell) | 1918 | F | DIM CHAN | First-person visions of luminous beings/other planes. |
| medium | [The Celtic Twilight](https://sacred-texts.com/neu/yeats/twi/index.htm) | W.B. Yeats | 1893/1902 | E | DIM | Contemporary encounter reports with the sidhe. |
| medium | [The Coming of the Fairies](https://sacred-texts.com/neu/eng/cof/index.htm) | Arthur Conan Doyle | 1922 | F | DIM | Cottingley fairy photographs, spiritualist reading: modern 'evidence' reception. |
| medium | [The Fairy Mythology](https://sacred-texts.com/neu/celt/tfm/index.htm) | Thomas Keightley | 1870 | S | DIM ABD | Pan-European comparative survey of fairy peoples. |
| medium | [The Mabinogion](https://sacred-texts.com/neu/celt/mab/index.htm) | Lady Charlotte Guest | 1877 | P | DIM ABD | Pwyll's year in Annwn (the Otherworld); Rhiannon. |
| medium | [The Religion of the Ancient Celts](https://sacred-texts.com/neu/celt/rac/index.htm) | J.A. MacCulloch | 1911 | S | DIM | Scholarly treatment of the Tuatha/sidhe and the Otherworld. |
| medium | [Visions and Beliefs in the West of Ireland](https://sacred-texts.com/neu/celt/vbwi/index.htm) | Lady Augusta Gregory | 1920 | E | ABD DIM | Testimony of people 'taken' by the Sidhe; seers. |
| low | [Carmina Gadelica (Vol. I)](https://sacred-texts.com/neu/celt/cg1/index.htm) | Alexander Carmichael | 1900 | E | DIM | Hymns and charms; some fairy material. |
| low | [Fairy Legends and Traditions](https://sacred-texts.com/neu/celt/flat/index.htm) | T. Crofton Croker | 1825 | E | DIM | Early Irish fairy lore. |
| low | [Tales of Fairies and of the Ghost World](https://sacred-texts.com/neu/celt/tfgw/index.htm) | Jeremiah Curtin | 1895 | E | ABD DIM | Irish fairy abduction tales. |
| low | [The Barddas (Vol. I)](https://sacred-texts.com/neu/celt/bim1/index.htm) | Iolo Morganwg, ed. J. Williams ab Ithel | 1862 | F | DIM | Neo-Druidic cosmology (circles of Abred/Gwynfyd); largely forgery: fringe. |

### England  (`eng`)

Index: https://sacred-texts.com/neu/eng/index.htm  
Status: **relevant**. Merlin's incubus paternity, pixie lore; moderate-low.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [Histories of the Kings of Britain](https://sacred-texts.com/neu/eng/gem/index.htm) | Geoffrey of Monmouth, tr. Sebastian Evans | 1904 | P | HYB | Merlin begotten by an incubus 'between the moon and the earth' (citing Apuleius): hybrid-birth motif. |
| low | [Popular Romances of the West of England](https://sacred-texts.com/neu/eng/prwe/index.htm) | Robert Hunt | 1903 | E | DIM ABD | Cornish piskies, giants, fairy abductions. |
| low | [Tales of the Dartmoor Pixies](https://sacred-texts.com/neu/eng/tdp/index.htm) | William Crossing | 1890 | E | DIM | Pixie lore. |

### Icelandic / Norse  (`ice`)

Index: https://sacred-texts.com/neu/ice/index.htm  
Status: **relevant**. Aesir/Vanir, Nine Worlds, Rigsthula, euhemerized Odin as migrant culture-bringer.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [The Poetic Edda](https://sacred-texts.com/neu/poe/index.htm) | Henry Adams Bellows | 1936 | P | CULT HYB SKY | Voluspo, Nine Worlds; Rigsthula: the god Rig (Heimdall) fathers the social classes and teaches runes. |
| medium | [Heimskringla (Ynglinga Saga)](https://sacred-texts.com/neu/heim/index.htm) | Snorri Sturluson, tr. Samuel Laing | 1844 | P | CULT | Euhemerized Odin: leader from Asaland who migrated north and taught skills and magic. |
| medium | [The Prose Edda](https://sacred-texts.com/neu/pre/index.htm) | tr. A.G. Brodeur | 1916 | P | CULT SKY | Gylfaginning; Aesir framed as migrants from Troy/Asia; Bifrost. |
| low | [Teutonic Myth and Legend](https://sacred-texts.com/neu/tml/index.htm) | Donald A. Mackenzie | 1912 | S | DIM | Survey of Norse/Germanic gods, elves, dwarfs. |

### Basque  (`basque`)

Index: https://sacred-texts.com/neu/basque/index.htm  
Status: **marginal**. Lamiñak fairy folk only; low.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| low | [Basque Legends](https://sacred-texts.com/neu/basque/bl/index.htm) | Wentworth Webster | 1879 | E | DIM | Lamiñak fairy folk. |

### Roma  (`roma`)

Index: https://sacred-texts.com/neu/roma/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### Legendary Creatures  (`lcr`)

Index: https://sacred-texts.com/lcr/index.htm  
Status: **cross-listed / marginal (see note)**. Dragons, unicorns, cryptids; not visitor material (low).

### Comparative  (`comp`)

Index: https://sacred-texts.com/comp/index.htm  
Status: **cross-listed / marginal (see note)**. Methodological background only (e.g., Rank on divine-birth hero myths).

### Mysticism  (`myst`)

Index: https://sacred-texts.com/myst/index.htm  
Status: **cross-listed / marginal (see note)**. Visionary literature; AE's Candle of Vision is the one directly relevant item (listed under Celtic).

### Swedenborg  (`swd`)

Index: https://sacred-texts.com/swd/index.htm  
Status: **relevant**. Earths in the Universe (1758): spirits from Mercury, Venus, Mars, the Moon and planets of other stars.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Earths in the Universe](https://sacred-texts.com/swd/eiu/index.htm) | Emanuel Swedenborg | 1758 | F | PLUR CHAN | Conversations with spirits of the inhabitants of Mercury, Venus, Mars, Jupiter, Saturn, the Moon and 'earths in the starry heaven'. |
| medium | [Heaven and Hell](https://sacred-texts.com/swd/hh/index.htm) | Emanuel Swedenborg | 1758 | F | DIM PLUR | Angelic societies; spirits from other earths. |

### Mormonism  (`mor`)

Index: https://sacred-texts.com/mor/index.htm  
Status: **relevant**. Pearl of Great Price: Kolob star near God's throne; worlds without number.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [Pearl of Great Price](https://sacred-texts.com/mor/pgp/index.htm) | Joseph Smith | 1851 | P | STAR PLUR | Book of Abraham: Kolob, the great star nearest God's throne; Book of Moses: worlds without number. |
| low | [The Book of Mormon](https://sacred-texts.com/mor/bom.htm) | Joseph Smith | 1830 | P | SKY | Brother of Jared's stones lit by the finger of God; the risen Christ descends from heaven in the Americas. |

### Oahspe  (`oah`)

Index: https://sacred-texts.com/oah/index.htm  
Status: **relevant**. Channeled 'Kosmon Bible' (1882): etherean fire-ships, angel embassadors. Fringe/NRM.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Oahspe, A Kosmon Bible](https://sacred-texts.com/oah/oah/index.htm) | John Ballou Newbrough | 1882 | F | VEH CHAN HYB SKY | Channeled: etherean fire-ships/airships of angels, angel embassadors, prehistoric hybrid races (I'hins, druks). |

### Theosophy  (`the`)

Index: https://sacred-texts.com/the/index.htm  
Status: **relevant**. Lords of the Flame / Sanat Kumara from Venus; Stanzas of Dzyan; root races. Fringe but historically central to modern 'space brother' ideas.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [A Textbook of Theosophy](https://sacred-texts.com/the/tot/index.htm) | C.W. Leadbeater | 1912 | F | SKY CULT PLUR | Lords of the Flame came from Venus to guide earth's evolution. |
| high | [Initiation, Human and Solar](https://sacred-texts.com/eso/ihas/index.htm) | Alice A. Bailey | 1922 | F | SKY CULT PLUR CHAN | 'The Founding of the Hierarchy': Sanat Kumara comes 'down to this dense physical planet' ~18 million years ago (CORRECTED 2026-09-26: ch. IV does not name Venus; the Venus origin is Scott-Elliot 1904, Leadbeater 1912, Ballard 1934). |
| high | [The Book of Dzyan (excerpt)](https://sacred-texts.com/atl/dzyan/dzyan.htm) | Helena P. Blavatsky | 1888 | F | SKY HYB | Purported Lemurian scripture: divine beings descend to form humanity. |
| high | [The Secret Doctrine](https://sacred-texts.com/the/sd/index.htm) | Helena P. Blavatsky | 1888 | F | SKY CULT HYB PLUR STAR | Stanzas of Dzyan; Lords of the Flame / Sons of Wisdom endow humanity with mind; root races: foundational text of modern 'star teacher' lore. |
| medium | [Isis Unveiled](https://sacred-texts.com/the/iu/index.htm) | Helena P. Blavatsky | 1877 | F | DIM | Survey of occult cosmology, elementals, ancient adepts. |

### Esoteric / Occult  (`eso`)

Index: https://sacred-texts.com/eso/index.htm  
Status: **relevant**. Enochian angelic communications, elemental peoples (Comte de Gabalis), Venusian masters (I AM), Bailey's Hierarchy.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [Comte de Gabalis](https://sacred-texts.com/eso/cdg/index.htm) | Abbe N. de Montfaucon de Villars | 1670 (1913 tr.) | F | DIM HYB VEH | Elemental peoples (sylphs, undines, gnomes, salamanders) seeking unions with humans; aerial ships of the sylphs. |
| high | [Unveiled Mysteries](https://sacred-texts.com/eso/um/index.htm) | Godfre Ray King (Guy W. Ballard) | 1934 | F | PLUR CHAN SKY | I AM movement: St Germain at Mt Shasta; ch. IX 'Venus Visits the Royal Teton' (Venusian masters). |
| medium | [Enochian Magic section & The Calls of Enoch](https://sacred-texts.com/eso/enoch/index.htm) | John Dee & Edward Kelley (various eds.) | 1580s | P | CHAN DIM | Angelic communications by scrying; Enochian language: key early-modern 'contact' corpus. |
| medium | [The Secret Teachings of All Ages](https://sacred-texts.com/eso/sta/index.htm) | Manly P. Hall | 1928 | F | CULT DIM | Encyclopedic esoterica incl. Oannes, Hermes, elementals. |
| low | [A Wanderer in the Spirit Lands](https://sacred-texts.com/eso/wsl/index.htm) | Franchezzo (A. Farnese) | 1896 | F | ABD CHAN | Spiritualist otherworld travelogue. |
| low | [Tertium Organum](https://sacred-texts.com/eso/to/index.htm) | P.D. Ouspensky | 1922 | F | DIM | Fourth dimension as a model for higher beings/consciousness. |
| low | [The Chaldaean Oracles of Zoroaster](https://sacred-texts.com/eso/coz/index.htm) | W. Wynn Westcott | 1895 | P | DIM | Late-antique theurgy: intermediary daemons. |

### Atlantis / Lemuria / Mu  (`atl`)

Index: https://sacred-texts.com/atl/index.htm  
Status: **relevant**. Modern pseudo-history & channeled prehistory: reception history, fringe as evidence.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [The Lost Lemuria](https://sacred-texts.com/atl/tll/index.htm) | W. Scott-Elliot | 1904 | F | SKY PLUR CULT | Arrival of the Lords of the Flame from Venus in Lemurian times. |
| high | [The Story of Atlantis](https://sacred-texts.com/atl/soa/index.htm) | W. Scott-Elliot | 1896 | F | CULT PLUR | Theosophical prehistory: divine rulers guiding the Atlantean races. |
| medium | [A Dweller on Two Planets](https://sacred-texts.com/atl/dtp/index.htm) | Frederick S. Oliver ('Phylos') | 1905 | F | VEH PLUR CHAN | Automatic-writing novel: Atlantean airships (vailx) and a journey to Venus. |
| medium | [Atlantis, the Antediluvian World](https://sacred-texts.com/atl/ataw/index.htm) | Ignatius Donnelly | 1882 | F | CULT | Ancient gods as deified Atlantean kings: euhemerist diffusionism that prefigures ancient-astronaut theory. |
| medium | [Vril, the Power of the Coming Race](https://sacred-texts.com/atl/vril/index.htm) | Edward Bulwer-Lytton | 1871 | L | DIM | Novel of an advanced subterranean race; later absorbed into occult/UFO lore. |
| low | [Selestor's Men of Atlantis](https://sacred-texts.com/atl/smoa/index.htm) | Clara Iza von Ravn | 1937 | F | CHAN | Channeled Atlantean history. |
| low | [The Sacred Symbols of Mu](https://sacred-texts.com/atl/ssm/index.htm) | James Churchward | 1933 | F | CULT | Lost continent Mu as source of all religions. |

### UFOs  (`ufo`)

Index: https://sacred-texts.com/ufo/index.htm  
Status: **relevant**. Dedicated section EXISTS (ufo/): 1900-1959 books plus ~200 1990s BBS text files incl. Dogon, vimanas, Nephilim-as-ufonauts, jinn-as-UFO-entities, Sitchin review.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| high | [From India to the Planet Mars](https://sacred-texts.com/ufo/ipm/index.htm) | Theodore Flournoy, tr. D.B. Vermilye | 1900 | S | CHAN PLUR | Psychologist's case study of medium Helene Smith's 'Martian' language and visions: primary for psychological readings of contact. |
| high | [Heaven's Gate](https://sacred-texts.com/ufo/hg/index.htm) | Heaven's Gate group | 1990s | U | CHAN VEH SKY | NRM writings: 'Evolutionary Level Above Human', spacecraft as heaven: key modern case study. |
| high | [I Remember Lemuria](https://sacred-texts.com/ufo/irl/index.htm) | Richard S. Shaver | 1948 | U | DIM PLUR HYB | Titans/Atlans from space and degenerate 'deros' in caverns: bridge from Lemuria lore to the UFO craze. |
| high | [In Days To Come](https://sacred-texts.com/ufo/idtc/index.htm) | 'Ashtar' (Ethel P. Hill) | 1957? | U | CHAN PLUR | Channeled Ashtar messages. |
| high | [Other Tongues--Other Flesh](https://sacred-texts.com/ufo/otof/index.htm) | George Hunt Williamson | 1953 | U | PLUR HYB SKY CHAN | Ancient-astronaut and 'Wanderers' doctrine; Maldek; reinterprets scripture as extraterrestrial history. |
| high | [The Secret of the Saucers](https://sacred-texts.com/ufo/sos/index.htm) | Orfeo M. Angelucci, ed. Ray Palmer | 1955 | U | CHAN VEH ABD | Early contactee account of benevolent 'space brothers'. |
| high | [We Met the Space People](https://sacred-texts.com/ufo/wmsp/index.htm) | Helen & Betty Mitchell | 1959 | U | CHAN PLUR | Contactees meet 'Space Brothers' from Venus. |
| medium | [A Brief Account of the True Nature of the UFO Entities [BBS file]](https://sacred-texts.com/ufo/jinns.htm) | anon. BBS text | 1990s | F | DIM | Identifies UFO entities with Islamic jinn. |
| medium | [Ancient Indian Aircraft Technology [BBS file]](https://sacred-texts.com/ufo/aiac.htm) | anon. BBS text | 1990s | F | VEH | Vimana claims (Vaimanika Shastra etc.); the Sanskrit sources themselves are not hosted. |
| medium | [Flying Aircraft and Nuclear War... of the Past [BBS file]](https://sacred-texts.com/ufo/ourpast.htm) | anon. BBS text | 1990s | F | VEH WAR | Mahabharata-as-nuclear-war and vimana claims. |
| medium | [Flying Saucers: The Bible Connection [BBS file]](https://sacred-texts.com/ufo/bibleufo.htm) | anon. BBS text | 1990s | F | VEH SKY | Ezekiel/Elijah-as-UFO readings. |
| medium | [My Trip to Mars](https://sacred-texts.com/ufo/mars/mttm/index.htm) | William Ferguson | 1959 | U | CHAN ABD PLUR | Contactee's out-of-body trip to Mars. |
| medium | [Review of 'The 12th Planet' [BBS file]](https://sacred-texts.com/ufo/sitchin.htm) | anon. BBS text | 1990s | F | SKY HYB CULT | Summary/critique of Sitchin's Anunnaki-from-Nibiru thesis (Sitchin not hosted). |
| medium | [The Dogon [BBS file]](https://sacred-texts.com/ufo/dogon.htm) | Richard Dolan (Usenet post) | 1995 | F | STAR CULT | The ONLY Dogon/Sirius item on the site: a Usenet post summarizing Temple-style claims; no Griaule/Dieterlen text hosted. |
| medium | [The Flying Saucers Are Real](https://sacred-texts.com/ufo/fsar/index.htm) | Donald Keyhoe | 1950 | U | VEH PLUR | Classic nuts-and-bolts ET hypothesis; secular context. |
| medium | [The Planet Mars and its Inhabitants](https://sacred-texts.com/ufo/mars/mah/index.htm) | 'Eros Urides', ed. J.L. Kennon | 1922 | U | CHAN PLUR | Channeled description of Martian civilization. |
| medium | [Who are the Ufonauts? (Book of Enoch) [BBS file]](https://sacred-texts.com/ufo/nephilim.htm) | anon. BBS text | 1990s | F | FORB HYB SKY | Reads Enoch's Watchers/Nephilim as ufonauts: fringe reception of Enoch. |
| low | [Betty Hill Star Map [BBS file]](https://sacred-texts.com/ufo/mapup.htm) | anon. | 1990s | U | STAR ABD | Hill abduction star map: modern abduction case. |
| low | [Flying Saucers-Top Secret: The Piri Reis Map [BBS file]](https://sacred-texts.com/ufo/piri.htm) | anon. | 1990s | F | - | Ancient-astronaut claims about the Piri Re'is map. |
| low | [The Report on Unidentified Flying Objects](https://sacred-texts.com/ufo/rufo/index.htm) | Edward J. Ruppelt | 1956 | U | VEH | USAF Project Blue Book memoir; secular baseline. |
| low | [Tibetan Disks [BBS file]](https://sacred-texts.com/ufo/tibdisc.htm) | anon. BBS text | 1990s | F | VEH | Dropa-stones legend (hoax lineage). |

### Fortean  (`fort`)

Index: https://sacred-texts.com/fort/index.htm  
Status: **relevant**. Charles Fort's catalogues of anomalous aerial phenomena.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [New Lands](https://sacred-texts.com/fort/land/index.htm) | Charles Fort | 1923 | F | VEH PLUR | Anomalous lights/objects in the sky; hypothesis of visiting 'super-constructions'. |
| medium | [The Book of the Damned](https://sacred-texts.com/fort/damn/index.htm) | Charles Fort | 1919 | F | VEH PLUR | 'I think we're property': archetype of the owned-humanity hypothesis. |
| low | [Lo!](https://sacred-texts.com/fort/lo/index.htm) | Charles Fort | 1931 | F | ABD | Teleportation, disappearances, anomalous falls. |

### Earth Mysteries  (`earth`)

Index: https://sacred-texts.com/earth/index.htm  
Status: **relevant**. Hollow-earth races, enchanted Atlantic isles, pyramidology; fringe/low-medium.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [Tales of the Enchanted Islands of the Atlantic](https://sacred-texts.com/earth/teia/index.htm) | Thomas Wentworth Higginson | 1898 | L | ABD DIM TIME | St Brendan, Isle of the Seven Cities and other otherworld islands. |
| low | [Etidorhpa](https://sacred-texts.com/earth/eti/index.htm) | John Uri Lloyd | 1897 | L | DIM ABD | Journey into the hollow earth guided by an eyeless being. |
| low | [The Smoky God](https://sacred-texts.com/earth/smog/index.htm) | Willis George Emerson | 1908 | L | DIM | Hollow-earth novel with a race of giants inside. |

### Piri Re'is Map  (`piri`)

Index: https://sacred-texts.com/piri/index.htm  
Status: **cross-listed / marginal (see note)**. The map is not religious; ancient-astronaut claims about it are in ufo/piri.htm (fringe).

### Parapsychology  (`psi`)

Index: https://sacred-texts.com/psi/index.htm  
Status: **cross-listed / marginal (see note)**. Flournoy's medium with 'Martian' communications (listed under UFOs).

### Thelema  (`oto`)

Index: https://sacred-texts.com/oto/index.htm  
Status: **relevant**. Liber AL dictated by Aiwass ('praeterhuman intelligence'); Amalantrah Working (source of 'Lam' lore).

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [Liber AL vel Legis (The Book of the Law)](https://sacred-texts.com/oto/engccxx.htm) | Aleister Crowley / 'Aiwass' | 1904 | F | CHAN | Dictated by Aiwass, whom Crowley called a 'praeterhuman intelligence'. |
| medium | [The Amalantrah Working (Soror Achitha's Vision)](https://sacred-texts.com/oto/lib97.txt) | Aleister Crowley | 1918 | F | CHAN | Sessions with a discarnate entity; the later 'Lam' figure was adopted into alien-contact lore. |
| low | [The Vision and the Voice](https://sacred-texts.com/oto/418/418.htm) | Aleister Crowley | 1909-11 | F | CHAN DIM | Scrying the 30 Enochian Aethyrs: angelic intelligences. |

### Neopaganism / Wicca  (`pag`)

Index: https://sacred-texts.com/pag/index.htm  
Status: **relevant**. Aradia sent from heaven by Diana to teach witchcraft; Murray's fairy-race theory.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| medium | [Aradia, or the Gospel of the Witches](https://sacred-texts.com/pag/aradia/index.htm) | Charles G. Leland | 1899 | F | SKY CULT HYB | Diana sends her daughter Aradia down to earth to teach witchcraft to the oppressed. |
| low | [The Witch-Cult in Western Europe](https://sacred-texts.com/pag/wcwe/index.htm) | Margaret Murray | 1921 | F | DIM | Theory that fairies were a real earlier race (discredited). |

### Book of Shadows  (`bos`)

Index: https://sacred-texts.com/bos/index.htm  
Status: **no clear relevant material**. NO clear relevant material (modern ritual texts).

### Grimoires  (`grim`)

Index: https://sacred-texts.com/grim/index.htm  
Status: **cross-listed / marginal (see note)**. Tangential: ritual evocation of spirits/angels (Goetia, Abramelin); not listed individually.

### Necronomicon  (`nec`)

Index: https://sacred-texts.com/nec/index.htm  
Status: **marginal**. Lovecraft fiction (Old Ones from the stars): reception history only.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| low | [H.P. Lovecraft texts](https://sacred-texts.com/nec/hpl/index.htm) | H.P. Lovecraft | 1926-36 | L | PLUR SKY | Fiction: Old Ones and Mi-Go from the stars; major influence on ancient-alien imagery. |

### Women  (`wmn`)

Index: https://sacred-texts.com/wmn/index.htm  
Status: **cross-listed / marginal (see note)**. Low; 'Unveiling a Parallel' (1893) is a Mars-voyage utopian novel.

### Utopia  (`utopia`)

Index: https://sacred-texts.com/utopia/index.htm  
Status: **cross-listed / marginal (see note)**. Low; imaginary-voyage literature (Symzonia, New Atlantis).

### Tolkien sources  (`ring`)

Index: https://sacred-texts.com/ring/index.htm  
Status: **cross-listed / marginal (see note)**. Duplicates Eddas/Kalevala; nothing additional.

### Sacred Books of the East  (`sbe`)

Index: https://sacred-texts.com/sbe/index.htm  
Status: **cross-listed / marginal (see note)**. Series index; relevant volumes listed under Hinduism, Buddhism, Jainism, Zoroastrianism, Islam.

### Wisdom of the East  (`woe`)

Index: https://sacred-texts.com/woe/index.htm  
Status: **cross-listed / marginal (see note)**. Series index; nothing additional.

### Age of Reason  (`aor`)

Index: https://sacred-texts.com/aor/index.htm  
Status: **marginal**. Low: Paine's Age of Reason argues from plurality of worlds against Christian cosmology.

| Rel. | Title | Author/translator | Year | Type | Motifs | Reason |
|---|---|---|---|---|---|---|
| low | [Age of Reason](https://sacred-texts.com/aor/paine/aor/index.htm) | Thomas Paine | 1794 | S | PLUR | Plurality of worlds used to argue against Christian redemption cosmology. |

### Philosophy  (`phi`)

Index: https://sacred-texts.com/phi/index.htm  
Status: **no clear relevant material**. NO clear relevant material (Plato's Timaeus/Critias indexed under Classics).

### Miscellaneous  (`etc`)

Index: https://sacred-texts.com/etc/index.htm  
Status: **cross-listed / marginal (see note)**. Low (serpent worship, nature myths).

### Gothic  (`goth`)

Index: https://sacred-texts.com/goth/index.htm  
Status: **no clear relevant material**. NO clear relevant material (vampires, werewolves).

### Evil  (`evil`)

Index: https://sacred-texts.com/evil/index.htm  
Status: **cross-listed / marginal (see note)**. Low (history of the Devil: fallen-angel background only).

### Sub Rosa  (`sro`)

Index: https://sacred-texts.com/sro/index.htm  
Status: **cross-listed / marginal (see note)**. Low (Comte de St Germain legend feeds I AM 'Ascended Master' lore).

### Freemasonry  (`mas`)

Index: https://sacred-texts.com/mas/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### Alchemy  (`alc`)

Index: https://sacred-texts.com/alc/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### Astrology  (`astro`)

Index: https://sacred-texts.com/astro/index.htm  
Status: **cross-listed / marginal (see note)**. Low: star/planet lore background (Cumont listed under Classics).

### Time  (`time`)

Index: https://sacred-texts.com/time/index.htm  
Status: **no clear relevant material**. NO clear relevant material (calendars).

### Americana  (`ame`)

Index: https://sacred-texts.com/ame/index.htm  
Status: **cross-listed / marginal (see note)**. Low (Skinner's Myths and Legends of Our Own Land).

### Journals  (`journals`)

Index: https://sacred-texts.com/journals/index.htm  
Status: **no clear relevant material**. NO clear relevant material found in article titles.

### LGBT  (`lgbt`)

Index: https://sacred-texts.com/lgbt/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### Sacred Sexuality  (`sex`)

Index: https://sacred-texts.com/sex/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### Tantra  (`tantra`)

Index: https://sacred-texts.com/tantra/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### Tarot  (`tarot`)

Index: https://sacred-texts.com/tarot/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### Symbolism  (`sym`)

Index: https://sacred-texts.com/sym/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### I Ching  (`ich`)

Index: https://sacred-texts.com/ich/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### Shakespeare  (`sks`)

Index: https://sacred-texts.com/sks/index.htm  
Status: **no clear relevant material**. NO clear relevant material (fairy lore in plays is literary).

### Nostradamus  (`nos`)

Index: https://sacred-texts.com/nos/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### Prophecy  (`pro`)

Index: https://sacred-texts.com/pro/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### New Thought  (`nth`)

Index: https://sacred-texts.com/nth/index.htm  
Status: **no clear relevant material**. NO clear relevant material.

### DNA  (`dna`)

Index: https://sacred-texts.com/dna/index.htm  
Status: **no clear relevant material**. NO relevant material (genome excerpt).

### Paleolithic  (`nel`)

Index: https://sacred-texts.com/nel/index.htm  
Status: **no clear relevant material**. NO relevant material (cave-painting notes only).

## 4. Traditions with no clear relevant material / gaps

- No clear relevant material: Sikhism, Baha'i, Confucian canon (except Werner's survey), Roma, Book of Shadows, Freemasonry, Alchemy, Gothic, Philosophy, Journals, LGBT, Sexuality, Tantra, Tarot, Symbolism, I Ching, Shakespeare, Nostradamus, Prophecy, New Thought, Time, DNA, Paleolithic.
- Weak/marginal: Taoism (Lieh-tzu only), Basque, Legendary Creatures (dragons, cryptids - not visitors), Astrology, Americana, Utopia, Women, Tolkien sources, Evil, Sub Rosa, Grimoires (ritual spirit-contact only).
- Within Africa: no East African (except Werner's Bantu survey and Kebra Nagast), no Dogon/Mande, no Egyptian-African linkage beyond Afrocentric secondary works; Rastafarian and Vodun texts contain no NHI motifs.
- Missing classics of the topic not on the site: Griaule's Conversations with Ogotemmeli/Pale Fox, Vaimanika Shastra, Lebor Gabala Erenn in full (only via Gregory/Squire/Rolleston retellings), Bhagavata Purana (only Prem Sagar adaptation), Plutarch's 'On the Face in the Moon'.

## 5. Methodological caveats

- Most texts are public-domain works from c.1830-1930: colonial-era ethnographies and missionary reports (e.g., Callaway, Dennett, Nassau, Ellis, Parker, Spencer & Gillen) filtered through outsider categories ('fetich', 'primitive'), selective informants and translation choices. Treat them as mediated records, not transparent indigenous voice; check modern ethnographies and community sources.
- Many translations are superseded (Budge's Egyptian/Ethiopic, Laurence's Enoch, King's Babylonian texts, Griffith's Vedas, Chamberlain's Kojiki). Verify key passages against current critical editions before quoting (e.g., Nickelsburg/VanderKam for 1 Enoch, George for Gilgamesh, ETCSL for Sumerian).
- Retold/popular collections for children or general readers (Mackenzie, Ogumefu, Westervelt, Parker's Legendary Tales, Lang, Jacobs) paraphrase and harmonize; use them for leads, not as primary evidence.
- Source-type flags: P = primary text in translation; E = ethnography/folklore collection; S = secondary scholarship; F = modern esoteric/pseudo-historical/fringe; U = modern UFO/contactee/NRM document; L = literary fiction. F and U items are 'fringe = true' in index.json: they are primary sources only for the study of modern esotericism, NRMs and the reception history of ancient-astronaut ideas - not evidence about ancient beliefs.
- Interpretive risk: the motif lens (sky descent, vehicles, hybrids) invites anachronistic 'ancient astronaut' readings. Emic categories (orisha, sidhe, jinn, devas, Watchers, katsina) have their own theological logics; code motifs descriptively and keep etic NHI framing explicit.
- Coverage limits: sacred-texts is a curated, English-language, public-domain library with strong Anglo/Celtic/Theosophical skew and thin coverage of Africa (29 items, mostly southern/western Africa and the diaspora), Islam beyond Qur'an/Sufism, and living oral traditions. Absence on the site is not absence in the tradition.
- Dogon/Sirius: Griaule & Dieterlen are NOT hosted; the only item is a 1995 Usenet repost (ufo/dogon.htm). The Griaule material is itself contested (van Beek 1991 re-study). Vimana technical texts (Vaimanika Shastra, Samarangana Sutradhara) and Sitchin are likewise not hosted - only BBS summaries.
- Relevance scores are the indexer's judgement from category descriptions and tables of contents (not full reads). 'high' = explicit, sustained motif; 'medium' = clear but partial or survey-level; 'low' = incidental/background; 'none' (Africa only, listed for completeness).

## Appendix: method
- Fetched sacred-texts.com root and afr/ (new site layout, JS-heavy) plus the classic category index pages from archive.sacred-texts.com (same paths), ~1 request/sec, saved under raw/. Tables of contents of all 29 African books and ~35 other candidate books were fetched to judge relevance; no book bodies were mirrored.
- Scores are judgements from TOCs/descriptions plus prior knowledge of the texts; verify during the reading phase.


## Supplementary: Biblioteca Pleyades

Added 2026-09-26. Full detail in [index_pleyades.md](index_pleyades.md) / index_pleyades.json (166 items; high 36, medium 81, low 49; types P 23, E 4, S 32, F 101, C 6). Source-type scheme there: P primary, E ethnography/academic, S secondary, F fringe, C skeptic critique. The same motif codes are used.

**Most useful additions:** Josyer's Vaimanika Shastra (1973); full Popol Vuh (Goetz/Morley); Dalley's Atrahasis and Adapa; Qumran Watcher texts (Book of Giants, Genesis Apocryphon); Temple's Sirius Mystery, which includes a translation of Griaule & Dieterlen 1950; Coppens's summary of van Beek's critique; Heiser's critique of Sitchin; the Credo Mutwa interview; Korean Tan'gun/Tongmyong texts; Vallee's Passport to Magonia and his JSE 1990 paper; Berzin on Shambhala myths.

### Revised gap table (sacred-texts + Biblioteca Pleyades)

| Gap | Status | Best sources | Comment |
|---|---|---|---|
| Dogon/Nommo/Sirius (Griaule & Dieterlen; Temple; van Beek critique) | **partial** | [siriusmystery.htm](https://www.bibliotecapleyades.net/universo/siriusmystery/siriusmystery.htm)<br>[esp_sirio10.htm](https://www.bibliotecapleyades.net/universo/esp_sirio10.htm)<br>[esp_vida_alien_18zo.htm](https://www.bibliotecapleyades.net/vida_alien/esp_vida_alien_18zo.htm) | Temple's full book is here, including an English translation of Griaule & Dieterlen 1950 ('A Sudanese Sirius System'). The critique is present only as Coppens's summary of van Beek. Not on the site: Griaule's 'Dieu d'eau/Conversations with Ogotemmêli' (1948/1965), 'Le Renard pâle' (1965), and van Beek 1991 itself (external PDF: drmsh.com/PaleoBabble/Grialle%20Sirius%20Dogon.pdf; Current Anthropology 32(2):139-167). |
| Vaimanika Shastra / Samarangana Sutradhara / 1974 IISc critique | **partial** | [default.htm](https://www.bibliotecapleyades.net/vimanas/vs/default.htm)<br>[vimanas.htm](https://www.bibliotecapleyades.net/vimanas/vimanas.htm)<br>[esp_vimanas_1.htm](https://www.bibliotecapleyades.net/vimanas/esp_vimanas_1.htm) | Filled: Josyer's 1973 Vaimanika translation, a Wayback copy of what sacred-texts once hosted, plus the 2001 AR&DB study, which documents Subbaraya Shastry's dictation in 1918-23. The Samarangana appears only as a Spanish paraphrase. The IISc critique is NOT on the site (checked). External reference: Mukunda, Deshpande, Nagendra, Prabhu & Govindaraju 1974, 'A critical study of the work Vyamanika Shastra', Scientific Opinion, pp. 5-12. |
| Sitchin/Anunnaki and critiques | **filled** | [12planeteng_index.htm](https://www.bibliotecapleyades.net/sitchin/planeta12/12planeteng_index.htm)<br>[esp_sitchin_21.htm](https://www.bibliotecapleyades.net/sitchin/esp_sitchin_21.htm)<br>[boulay03e_a.htm](https://www.bibliotecapleyades.net/serpents_dragons/boulay03e_a.htm) | Sitchin's books are reproduced in full. Critiques: Heiser's philology article (the fuller sitchiniswrong.com material is not on the site), the 'space module' plaster debunk, and Sagan-vs-von Däniken (Spanish). Bonus: Dalley's Atrahasis and Adapa and Foster's Erra, which are the primary texts Sitchin relies on. |
| East/Southern Africa (Credo Mutwa, Chitauri, Zulu, Ethiopian) | **partial** | [esp_credo_mutwa03.htm](https://www.bibliotecapleyades.net/esp_credo_mutwa03.htm)<br>[esp_credo_mutwa04.htm](https://www.bibliotecapleyades.net/esp_credo_mutwa04.htm)<br>[contents.htm](https://www.bibliotecapleyades.net/enoch/contents.htm) | Credo Mutwa's Chitauri/Mantindane testimony (1999 interview) and his autobiographical texts are here. They are fringe-mediated (Icke/Spectrum) and contested. Ethiopian material is covered only by Kebra Nagast and 1 Enoch, which duplicate sacred-texts. There is no Zulu or Swahili ethnography, and Mutwa's 'Indaba, My Children' is not on the site. |
| Mesoamerica (Popol Vuh; Kukulkan/Quetzalcoatl) | **partial (primary filled)** | [book.htm](https://www.bibliotecapleyades.net/popol_vuh/book.htm)<br>[esp_mitoscreacion_11.htm](https://www.bibliotecapleyades.net/mitos_creacion/esp_mitoscreacion_11.htm)<br>[quetzalcoatl01.htm](https://www.bibliotecapleyades.net/arqueologia/quetzalcoatl01.htm) | Full Goetz/Morley Popol Vuh (sacred-texts index had only an excerpt). Quetzalcoatl/Kukulkan material is fringe-only; no Sahagún, Anales de Cuauhtitlan or Chilam Balam. |
| Andes (Viracocha) | **partial** | [viracocha01.htm](https://www.bibliotecapleyades.net/arqueologia/viracocha01.htm)<br>[esp_viracocha.htm](https://www.bibliotecapleyades.net/arqueologia/esp_viracocha.htm)<br>[secret-andes.pdf](https://www.bibliotecapleyades.net/archivos_pdf/secret-andes.pdf) | Sarmiento's Viracocha account duplicates sacred-texts. Adds Coppens's synthesis and Williamson's contactee book 'Secret of the Andes'. The Huarochirí Manuscript, Betanzos and Molina are not on the site. |
| Australia/Pacific (Wandjina) | **partial (weak)** | [esp_australia_sueno.htm](https://www.bibliotecapleyades.net/esp_australia_sueno.htm)<br>[aboriginal-men-high-degree.pdf](https://www.bibliotecapleyades.net/archivos_pdf/aboriginal-men-high-degree.pdf)<br>[esp_chaman_78.htm](https://www.bibliotecapleyades.net/cienciareal/esp_chaman_78.htm) | Only one anonymous Spanish fringe Wandjina page, which is inaccurate. Useful additions: an Elkin 'Men of High Degree' PDF, Chalker on shamanism and abduction, and Solomon Islands lore (a new Melanesian tradition). Scholarly Wandjina sources are needed externally (Crawford 1968; Blundell & Layton 1978; ANU Press chapter). |
| China/Tibet sky beings | **partial** | [esp_mitoscreacion_4.htm](https://www.bibliotecapleyades.net/mitos_creacion/esp_mitoscreacion_4.htm)<br>[sociopol_shambahla03.htm](https://www.bibliotecapleyades.net/sociopolitica/sociopol_shambahla03.htm)<br>[magic-mystery-tibet.pdf](https://www.bibliotecapleyades.net/archivos_pdf/magic-mystery-tibet.pdf) | No Chinese primary texts: nothing from the Shanhaijing, Huainanzi, Liexian zhuan, Chuci 'Li Sao' dragon-chariot flights, or Shiji on Huangdi's dragon ascent. Chinese content is limited to the Dropa hoax lore. NEW: Korean primary texts (Tan'gun; Haemosu's five-dragon chariot in the Lay of King Tongmyong), mislabelled 'China'. Tibet: Berzin's scholarly critique of Western Shambhala myths and David-Néel (PDF). |
| Primary translations not on sacred-texts | **partial-to-filled** | [esp_gigantes_3.htm](https://www.bibliotecapleyades.net/gigantes/esp_gigantes_3.htm)<br>[esp_enoch_7a.htm](https://www.bibliotecapleyades.net/enoch/esp_enoch_7a.htm)<br>[esp_leyenda_hopi08.htm](https://www.bibliotecapleyades.net/esp_leyenda_hopi08.htm) | Newly available: Vaimanika Shastra (Josyer); full Popol Vuh (Goetz/Morley); Atrahasis and Adapa (Dalley); Erra (Foster); Book of Giants, Genesis Apocryphon, 4Q227 and Testament of Amram (Qumran); Midrash of Shemhazai and Azael; Lockett's Hopi ethnography (1933); Korean Tan'gun/Tongmyong. Still not found in the sections reviewed (not searched exhaustively): Lebor Gabála Érenn in full, the Bhagavata Purana, and Plutarch's 'On the Face in the Moon'. |

**Caveats for Pleyades material:** (1) it is an aggregator, so cite the original publications it names, not the Pleyades URL; (2) it reproduces much copyrighted content (Temple, Sitchin, Dalley, Wise et al., Vallee, Elkin, Eliade), so use it only to locate passages; (3) it has a heavy fringe/conspiracy bias (about 60% F; only 6 C items), and indigenous voices are mediated by ufologists; (4) errors and mislabelling are frequent (e.g., the Korean myths filed as 'China'; invented Wandjina details).
